-- TrailFog group server setup for Supabase.
-- Paste this whole file into Supabase > SQL Editor > New query, then press Run.
-- Safe to run again: it only adds what is missing and replaces the functions.
--
-- How access works: the app never reads the tables directly (row level security
-- is on with no policies). Everything goes through the functions below, which
-- check the rider's private secret, and only return a group's data to its members.

create table if not exists riders (
  id         uuid primary key,
  secret     text not null,
  name       text not null default 'Rider',
  created_at timestamptz not null default now()
);

create table if not exists groups (
  code       text primary key,
  name       text not null,
  created_by uuid references riders(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists members (
  group_code text not null references groups(code) on delete cascade,
  rider_id   uuid not null references riders(id) on delete cascade,
  joined_at  timestamptz not null default now(),
  primary key (group_code, rider_id)
);

create table if not exists tracks (
  id         bigserial primary key,
  rider_id   uuid not null references riders(id) on delete cascade,
  ride       bigint not null,
  pts        jsonb not null,            -- [lat, lng, time, lat, lng, time, ...]
  created_at timestamptz not null default now()
);
create index if not exists tracks_rider_idx on tracks (rider_id);

create table if not exists photos (
  id         bigserial primary key,
  rider_id   uuid not null references riders(id) on delete cascade,
  local_id   bigint not null,
  lat        double precision not null,
  lng        double precision not null,
  t          bigint not null,
  img        text not null,             -- small JPEG, base64
  created_at timestamptz not null default now(),
  unique (rider_id, local_id)
);

-- Leaderboard additions. "public" riders appear on the world leaderboard.
-- The server works out every total itself from the uploaded points (see tf_process_chunk),
-- so a modified app can't just send made-up numbers.
alter table riders add column if not exists public boolean not null default false;
alter table riders add column if not exists hidden boolean not null default false;   -- set by you to remove a cheater from the world board
alter table tracks add column if not exists km double precision not null default 0;
alter table tracks add column if not exists new_cells integer not null default 0;
alter table tracks add column if not exists t0 bigint;
alter table tracks add column if not exists imported boolean not null default false;  -- from a GPX file: never counts on the world board
alter table tracks add column if not exists flagged boolean not null default false;   -- looks computer-made or impossible: never counts on any board
create index if not exists tracks_t0_idx on tracks (t0);

-- Every 50 m square of ground each rider has uncovered, and when.
create table if not exists rider_cells (
  rider_id uuid not null references riders(id) on delete cascade,
  ci       integer not null,
  cj       integer not null,
  first_t  bigint not null,
  primary key (rider_id, ci, cj)
);

-- Riders reported as cheating from the leaderboard.
create table if not exists reports (
  id         bigserial primary key,
  reporter   uuid not null references riders(id) on delete cascade,
  target     uuid not null references riders(id) on delete cascade,
  reason     text,
  created_at timestamptz not null default now(),
  unique (reporter, target)
);

alter table riders      enable row level security;
alter table groups      enable row level security;
alter table members     enable row level security;
alter table tracks      enable row level security;
alter table photos      enable row level security;
alter table rider_cells enable row level security;
alter table reports     enable row level security;
revoke all on riders, groups, members, tracks, photos, rider_cells, reports from anon, authenticated;

-- ---------- helpers ----------
create or replace function tf_check(p_rider uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from riders where id = p_rider and secret = p_secret) then
    raise exception 'Unknown rider';
  end if;
end $$;

create or replace function tf_member(p_rider uuid, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from members where group_code = p_code and rider_id = p_rider) then
    raise exception 'You are not in this group';
  end if;
end $$;

-- ---------- working out totals from the uploaded points ----------
create or replace function tf_dist(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns double precision language sql immutable as $$
  select 2 * 6378137 * asin(least(1, sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2))));
$$;

-- Marks one 50 m square as uncovered by a rider. Returns 1 if it is new ground, else 0.
create or replace function tf_add_cell(p_rider uuid, p_lat double precision, p_lng double precision, p_t bigint) returns integer
language plpgsql security definer set search_path = public as $$
declare
  dlat constant double precision := 50.0 / 111320;
  i integer := floor(p_lat / dlat);
  dlng double precision := dlat / greatest(0.01, cos(radians((i + 0.5) * dlat)));
  n integer;
begin
  insert into rider_cells (rider_id, ci, cj, first_t) values (p_rider, i, floor(p_lng / dlng)::integer, p_t)
  on conflict do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

-- Works out distance and new ground for one uploaded piece of trail, and flags it if it looks fake:
--  * moves faster than 150 km/h or jumps more than 300 m: that part doesn't count
--  * times in the future
--  * 30+ points in a perfectly straight line, perfectly evenly spaced (made by a computer, not GPS)
create or replace function tf_process_chunk(p_track bigint) returns void
language plpgsql security definer set search_path = public as $$
declare
  t tracks;
  n integer; i integer; k integer; steps integer;
  lat double precision; lng double precision; tt bigint;
  plat double precision; plng double precision; pt bigint; has_prev boolean := false;
  d double precision; dt double precision; f double precision;
  v_km double precision := 0; v_added integer := 0; first_t bigint := null;
  segs integer := 0; sum_d double precision := 0; sum_d2 double precision := 0; mean_d double precision;
  brg double precision; pbrg double precision; has_brg boolean := false; max_turn double precision := 0; turn double precision;
  bad boolean := false;
  prev_counted boolean := false;
  sum_dt double precision := 0; sum_dt2 double precision := 0;
  flat double precision; flng double precision; llat double precision; llng double precision; straight double precision;
  now_ms bigint := (extract(epoch from now()) * 1000)::bigint;
begin
  select * into t from tracks where id = p_track;
  if not found then return; end if;
  n := coalesce(jsonb_array_length(t.pts), 0) / 3;
  for i in 0 .. n - 1 loop
    begin
      lat := (t.pts->>(i * 3))::double precision;
      lng := (t.pts->>(i * 3 + 1))::double precision;
      tt  := (t.pts->>(i * 3 + 2))::bigint;
    exception when others then
      continue;
    end;
    if lat is null or lng is null or tt is null or abs(lat) > 85 or abs(lng) > 180 then continue; end if;
    if tt > now_ms + 86400000 then bad := true; end if;
    if first_t is null then first_t := tt; end if;
    if has_prev then
      d := tf_dist(plat, plng, lat, lng);
      dt := (tt - pt) / 1000.0;
      if dt > 0 and dt <= 600 and d <= 300 and d / dt <= 41.7 then
        v_km := v_km + d / 1000;
        if d > 0.5 then
          segs := segs + 1; sum_d := sum_d + d; sum_d2 := sum_d2 + d * d; sum_dt := sum_dt + dt; sum_dt2 := sum_dt2 + dt * dt;
          if flat is null then flat := plat; flng := plng; end if;
          llat := lat; llng := lng;
          brg := degrees(atan2(sin(radians(lng - plng)) * cos(radians(lat)),
                 cos(radians(plat)) * sin(radians(lat)) - sin(radians(plat)) * cos(radians(lat)) * cos(radians(lng - plng))));
          if has_brg then
            turn := abs(mod((brg - pbrg + 540)::numeric, 360) - 180);
            if turn > max_turn then max_turn := turn; end if;
          end if;
          pbrg := brg; has_brg := true;
        end if;
        -- ground only counts along real movement (not for lone or teleporting points)
        if not prev_counted then v_added := v_added + tf_add_cell(t.rider_id, plat, plng, pt); end if;
        steps := ceil(d / 25);
        for k in 1 .. steps - 1 loop
          f := k::double precision / steps;
          v_added := v_added + tf_add_cell(t.rider_id, plat + (lat - plat) * f, plng + (lng - plng) * f, tt);
        end loop;
        v_added := v_added + tf_add_cell(t.rider_id, lat, lng, tt);
        prev_counted := true;
      else
        has_brg := false;
        prev_counted := false;
      end if;
    end if;
    plat := lat; plng := lng; pt := tt; has_prev := true;
  end loop;
  if segs >= 60 then
    mean_d := sum_d / segs;
    straight := tf_dist(flat, flng, llat, llng);
    -- dead straight (path barely longer than a ruler line), evenly spaced and perfectly regular timing
    if straight > 0 and sum_d / straight < 1.003
       and sqrt(greatest(sum_d2 / segs - mean_d * mean_d, 0)) / mean_d < 0.025
       and sqrt(greatest(sum_dt2 / segs - power(sum_dt / segs, 2), 0)) / (sum_dt / segs) < 0.02 then
      bad := true;
    end if;
  end if;
  update tracks set km = least(v_km, 2000), new_cells = v_added, flagged = bad, t0 = coalesce(first_t, t.ride)
  where id = p_track;
end $$;

-- Rebuilds a rider's totals from scratch (after a ride is deleted).
create or replace function tf_recompute(p_rider uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  r record;
begin
  delete from rider_cells where rider_id = p_rider;
  for r in select id from tracks where rider_id = p_rider order by id loop
    perform tf_process_chunk(r.id);
  end loop;
end $$;

-- ---------- riders ----------
create or replace function register_rider(p_rider uuid, p_secret text, p_name text) returns void
language plpgsql security definer set search_path = public as $$
declare
  existing text;
  clean text := left(coalesce(nullif(trim(p_name), ''), 'Rider'), 30);
begin
  if length(coalesce(p_secret, '')) < 20 then raise exception 'Bad secret'; end if;
  select secret into existing from riders where id = p_rider;
  if existing is null then
    insert into riders (id, secret, name) values (p_rider, p_secret, clean);
  elsif existing = p_secret then
    update riders set name = clean where id = p_rider;
  else
    raise exception 'Unknown rider';
  end if;
end $$;

-- ---------- groups ----------
create or replace function create_group(p_rider uuid, p_secret text, p_name text) returns json
language plpgsql security definer set search_path = public as $$
declare
  c text;
  alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  i int;
  clean text := left(coalesce(nullif(trim(p_name), ''), 'My group'), 40);
begin
  perform tf_check(p_rider, p_secret);
  loop
    c := '';
    for i in 1..6 loop
      c := c || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from groups where code = c);
  end loop;
  insert into groups (code, name, created_by) values (c, clean, p_rider);
  insert into members (group_code, rider_id) values (c, p_rider);
  return json_build_object('code', c, 'name', clean);
end $$;

create or replace function join_group(p_rider uuid, p_secret text, p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare
  g groups;
begin
  perform tf_check(p_rider, p_secret);
  select * into g from groups where code = upper(trim(p_code));
  if not found then raise exception 'No group with that code'; end if;
  insert into members (group_code, rider_id) values (g.code, p_rider) on conflict do nothing;
  return json_build_object('code', g.code, 'name', g.name);
end $$;

create or replace function leave_group(p_rider uuid, p_secret text, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from members where group_code = p_code and rider_id = p_rider;
  delete from groups g where g.code = p_code and not exists (select 1 from members m where m.group_code = g.code);
end $$;

-- ---------- my trails ----------
create or replace function push_track(p_rider uuid, p_secret text, p_chunks jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare
  c jsonb;
  nid bigint;
begin
  perform tf_check(p_rider, p_secret);
  if jsonb_typeof(p_chunks) <> 'array' or jsonb_array_length(p_chunks) > 200 then raise exception 'Bad upload'; end if;
  -- The phone's own km / new-ground numbers are ignored; the server works them out.
  for c in select value from jsonb_array_elements(p_chunks) with ordinality order by ordinality loop
    if jsonb_typeof(c->'pts') <> 'array' or jsonb_array_length(c->'pts') < 3 or jsonb_array_length(c->'pts') > 15000 then continue; end if;
    insert into tracks (rider_id, ride, pts, imported)
    values (p_rider, (c->>'ride')::bigint, c->'pts', coalesce((c->>'src') = 'gpx', false))
    returning id into nid;
    perform tf_process_chunk(nid);
  end loop;
end $$;

-- Join or leave the world leaderboard.
create or replace function set_public(p_rider uuid, p_secret text, p_public boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  update riders set public = coalesce(p_public, false) where id = p_rider;
end $$;

-- Rankings. With a group code: that group's members. Without: the world
-- (riders who joined it and haven't been hidden). p_metric: 'ground' (km² of
-- new ground), 'km', 'rides'. Only names and totals are returned, never trails.
-- Flagged (fake-looking) trails never count; GPX imports don't count on the world board.
create or replace function leaderboard(p_rider uuid, p_secret text, p_code text, p_since bigint, p_metric text) returns json
language plpgsql security definer set search_path = public as $$
declare
  res json;
  in_group boolean := coalesce(trim(p_code), '') <> '';
begin
  perform tf_check(p_rider, p_secret);
  if in_group then perform tf_member(p_rider, p_code); end if;
  with pool as (
    select r.id, r.name from riders r
    where case when in_group
      then exists (select 1 from members m where m.group_code = p_code and m.rider_id = r.id)
      else r.public and not r.hidden end
  ),
  ok as (
    select t.* from tracks t join pool on pool.id = t.rider_id
    where not t.flagged and (in_group or not t.imported)
  ),
  vals as (
    select pool.id, pool.name,
      case p_metric
        when 'km' then coalesce((select sum(ok.km) from ok where ok.rider_id = pool.id and ok.t0 >= p_since), 0)
        when 'rides' then coalesce((select count(*) from (
                                      select ok.ride from ok where ok.rider_id = pool.id and ok.ride >= p_since
                                      group by ok.ride having sum(ok.km) >= 0.5) x), 0)
        else coalesce((select sum(ok.new_cells) from ok where ok.rider_id = pool.id and ok.t0 >= p_since), 0) * 0.0025
      end::double precision as v
    from pool
  ),
  ranked as (select id, name, v, rank() over (order by v desc) as rk from vals)
  select json_build_object(
    'top', coalesce((select json_agg(json_build_object('id', s.id, 'name', s.name, 'v', round(s.v::numeric, 2), 'rank', s.rk) order by s.rk, s.name)
                     from (select * from ranked where v > 0 order by rk, name limit 50) s), '[]'::json),
    'me', (select json_build_object('id', id, 'name', name, 'v', round(v::numeric, 2), 'rank', rk) from ranked where id = p_rider and v > 0),
    'riders', (select count(*) from ranked where v > 0)
  ) into res;
  return res;
end $$;

-- Report a rider on the world board or in your group as cheating (once per rider).
create or replace function report_rider(p_rider uuid, p_secret text, p_target uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  if p_target = p_rider then raise exception 'You cannot report yourself'; end if;
  if not exists (select 1 from riders r where r.id = p_target and r.public)
     and not exists (select 1 from members a join members b on a.group_code = b.group_code
                     where a.rider_id = p_rider and b.rider_id = p_target) then
    raise exception 'Rider not found';
  end if;
  insert into reports (reporter, target, reason) values (p_rider, p_target, left(coalesce(p_reason, ''), 200))
  on conflict (reporter, target) do update
    set reason = left(reports.reason || ' | ' || excluded.reason, 1000), created_at = now();
end $$;

create or replace function delete_ride(p_rider uuid, p_secret text, p_ride bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from tracks where rider_id = p_rider and ride = p_ride;
  perform tf_recompute(p_rider);
end $$;

create or replace function delete_my_tracks(p_rider uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from tracks where rider_id = p_rider;
  delete from rider_cells where rider_id = p_rider;
end $$;

-- ---------- my photos ----------
create or replace function push_photo(p_rider uuid, p_secret text, p_local_id bigint,
  p_lat double precision, p_lng double precision, p_t bigint, p_img text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  if length(p_img) > 2500000 then raise exception 'Photo too large'; end if;
  insert into photos (rider_id, local_id, lat, lng, t, img)
  values (p_rider, p_local_id, p_lat, p_lng, p_t, p_img)
  on conflict (rider_id, local_id) do nothing;
end $$;

create or replace function delete_photo(p_rider uuid, p_secret text, p_local_id bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from photos where rider_id = p_rider and local_id = p_local_id;
end $$;

-- ---------- reading a group ----------
-- Returns members, the ids of every trail chunk from other members (so deleted
-- ones can be dropped), up to 200 new chunks after p_since, and photo pins.
create or replace function group_data(p_rider uuid, p_secret text, p_code text, p_since bigint) returns json
language plpgsql security definer set search_path = public as $$
declare
  res json;
begin
  perform tf_check(p_rider, p_secret);
  perform tf_member(p_rider, p_code);
  select json_build_object(
    'group', (select json_build_object('code', g.code, 'name', g.name) from groups g where g.code = p_code),
    'members', coalesce((
      select json_agg(json_build_object('id', r.id, 'name', r.name) order by m.joined_at)
      from members m join riders r on r.id = m.rider_id
      where m.group_code = p_code), '[]'::json),
    'ids', coalesce((
      select json_agg(t.id)
      from tracks t join members m on m.rider_id = t.rider_id
      where m.group_code = p_code and t.rider_id <> p_rider), '[]'::json),
    'tracks', coalesce((
      select json_agg(x order by (x->>'id')::bigint) from (
        select json_build_object('id', t.id, 'rider', t.rider_id, 'ride', t.ride, 'pts', t.pts) as x
        from tracks t join members m on m.rider_id = t.rider_id
        where m.group_code = p_code and t.rider_id <> p_rider and t.id > p_since
        order by t.id
        limit 200) s), '[]'::json),
    'photos', coalesce((
      select json_agg(json_build_object('id', ph.id, 'rider', ph.rider_id, 'lat', ph.lat, 'lng', ph.lng, 't', ph.t) order by ph.t)
      from photos ph join members m on m.rider_id = ph.rider_id
      where m.group_code = p_code and ph.rider_id <> p_rider), '[]'::json)
  ) into res;
  return res;
end $$;

create or replace function get_photo(p_rider uuid, p_secret text, p_code text, p_photo bigint) returns text
language plpgsql security definer set search_path = public as $$
declare
  out_img text;
begin
  perform tf_check(p_rider, p_secret);
  perform tf_member(p_rider, p_code);
  select ph.img into out_img
  from photos ph join members m on m.rider_id = ph.rider_id
  where ph.id = p_photo and m.group_code = p_code;
  if out_img is null then raise exception 'Photo not found'; end if;
  return out_img;
end $$;

-- Only the app-facing functions can be called from the app.
revoke execute on function tf_check(uuid, text), tf_member(uuid, text),
  tf_add_cell(uuid, double precision, double precision, bigint), tf_process_chunk(bigint), tf_recompute(uuid)
  from public, anon, authenticated;
grant execute on function
  register_rider(uuid, text, text),
  create_group(uuid, text, text),
  join_group(uuid, text, text),
  leave_group(uuid, text, text),
  push_track(uuid, text, jsonb),
  delete_ride(uuid, text, bigint),
  delete_my_tracks(uuid, text),
  push_photo(uuid, text, bigint, double precision, double precision, bigint, text),
  delete_photo(uuid, text, bigint),
  group_data(uuid, text, text, bigint),
  get_photo(uuid, text, text, bigint),
  set_public(uuid, text, boolean),
  leaderboard(uuid, text, text, bigint, text),
  report_rider(uuid, text, uuid, text)
to anon, authenticated;

-- ---------- blocking riders ----------
-- A blocked rider's trails, photos and name are hidden from the rider who blocked them.
create table if not exists blocks (
  blocker    uuid not null references riders(id) on delete cascade,
  blocked    uuid not null references riders(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker, blocked)
);
alter table blocks enable row level security;
revoke all on blocks from anon, authenticated;

create or replace function block_rider(p_rider uuid, p_secret text, p_target uuid, p_block boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  if p_target = p_rider then raise exception 'You cannot block yourself'; end if;
  if p_block then
    insert into blocks (blocker, blocked) select p_rider, p_target where exists (select 1 from riders where id = p_target)
    on conflict do nothing;
  else
    delete from blocks where blocker = p_rider and blocked = p_target;
  end if;
end $$;

-- ---------- accounts: Sign in with Apple / Google (Supabase Auth) ----------
-- A signed-in account owns one rider. Signing in on a new phone gives that phone the
-- same rider back, so groups, leaderboard places and shared trails carry over.
alter table riders add column if not exists auth_user uuid unique;

create or replace function tf_rider_json(p_id uuid, p_existing boolean) returns json
language sql security definer set search_path = public as $$
  select json_build_object(
    'id', r.id, 'secret', r.secret, 'name', r.name, 'public', r.public, 'existing', p_existing,
    'groups', coalesce((select json_agg(json_build_object('code', g.code, 'name', g.name) order by m.joined_at desc)
                        from members m join groups g on g.code = m.group_code where m.rider_id = r.id), '[]'::json),
    'blocked', coalesce((select json_agg(json_build_object('id', b.blocked, 'name', x.name))
                         from blocks b join riders x on x.id = b.blocked where b.blocker = r.id), '[]'::json))
  from riders r where r.id = p_id;
$$;

-- Called right after signing in (needs the account's login token).
-- If the account already has a rider, returns it. Otherwise links this phone's rider to the account.
create or replace function claim_rider(p_rider uuid, p_secret text) returns json
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  r riders;
begin
  if uid is null then raise exception 'Please sign in first'; end if;
  if length(coalesce(p_secret, '')) < 20 then raise exception 'Bad secret'; end if;
  select * into r from riders where auth_user = uid;
  if found then return tf_rider_json(r.id, true); end if;
  select * into r from riders where id = p_rider;
  if found then
    if r.secret <> p_secret then raise exception 'Unknown rider'; end if;
    if r.auth_user is not null then raise exception 'This rider belongs to another account'; end if;
    update riders set auth_user = uid where id = p_rider;
  else
    insert into riders (id, secret, name, auth_user) values (p_rider, p_secret, 'Rider', uid);
  end if;
  return tf_rider_json(p_rider, false);
end $$;

-- Deletes the rider, everything they shared (trails, photos, groups, leaderboard totals,
-- reports they made), and their sign-in account.
create or replace function delete_account(p_rider uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_auth uuid;
  v_codes text[];
begin
  perform tf_check(p_rider, p_secret);
  select auth_user into v_auth from riders where id = p_rider;
  select array_agg(group_code) into v_codes from members where rider_id = p_rider;
  delete from riders where id = p_rider;   -- cascades to tracks, photos, members, rider_cells, reports
  -- groups left with nobody in them go too
  delete from groups g where g.code = any(coalesce(v_codes, '{}'))
    and not exists (select 1 from members m where m.group_code = g.code);
  if v_auth is not null then
    begin
      delete from auth.users where id = v_auth;
    exception when others then
      raise warning 'Could not delete sign-in account %: %', v_auth, sqlerrm;
    end;
  end if;
end $$;

-- My own shared trails, for putting them back on a new phone after signing in.
create or replace function my_tracks(p_rider uuid, p_secret text, p_since bigint) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  return coalesce((select json_agg(json_build_object('id', t.id, 'ride', t.ride, 'pts', t.pts, 'imported', t.imported) order by t.id)
    from (select * from tracks where rider_id = p_rider and id > coalesce(p_since, 0) order by id limit 200) t), '[]'::json);
end $$;

revoke all on function tf_rider_json(uuid, boolean) from public, anon, authenticated;
grant execute on function claim_rider(uuid, text), delete_account(uuid, text), my_tracks(uuid, text, bigint), block_rider(uuid, text, uuid, boolean) to anon, authenticated;

-- Give the app's requests a bit longer than Supabase's 3-second default, because the
-- server now works out totals from every point it receives.
alter role anon set statement_timeout = '20s';
alter role authenticated set statement_timeout = '20s';
notify pgrst, 'reload config';

-- One-time: work out totals for trails uploaded before this version.
select tf_recompute(r.id) from riders r
where exists (select 1 from tracks t where t.rider_id = r.id)
  and not exists (select 1 from rider_cells c where c.rider_id = r.id);

-- ============================================================================
-- ADMIN (run these yourself in the SQL Editor when needed; they are comments here)
--
-- Who has been reported, most first:
--   select r.name, r.id, r.hidden, count(*) as reports, max(rep.created_at) as last_report,
--          string_agg(distinct rep.reason, ' | ') as reasons
--   from reports rep join riders r on r.id = rep.target
--   group by r.id order by reports desc;
--
-- A rider's totals and anything flagged as fake:
--   select ride, round(km::numeric, 1) as km, new_cells, imported, flagged, to_timestamp(t0 / 1000) as at
--   from tracks where rider_id = 'PASTE-RIDER-ID' order by t0 desc;
--
-- Hide a cheater from the world leaderboard (and undo with false):
--   update riders set hidden = true where id = 'PASTE-RIDER-ID';
--
-- A rider's photos (the reason says "photo 123: ..." when a photo was reported):
--   select id, to_timestamp(t / 1000) as taken, lat, lng from photos where rider_id = 'PASTE-RIDER-ID';
-- Remove a bad photo:
--   delete from photos where id = 123;
-- Rename a rider with an offensive name:
--   update riders set name = 'Rider' where id = 'PASTE-RIDER-ID';
-- Ban a rider completely (removes them and everything they shared):
--   delete from riders where id = 'PASTE-RIDER-ID';
-- ============================================================================
