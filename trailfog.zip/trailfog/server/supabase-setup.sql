-- TrailFog group server setup for Supabase.
-- Paste this whole file into Supabase > SQL Editor > New query, then press Run.
-- Safe to run again: it only adds what is missing and replaces the functions.
--
-- How access works: the app never reads the tables directly (row level security
-- is on with no policies). Everything goes through the functions below, which
-- check the rider's private secret, and only return a group's data to its members.

create table if not exists riders (
  id         uuid primary key,
  secret     text not null,
  name       text not null default 'Rider',
  created_at timestamptz not null default now()
);

create table if not exists groups (
  code       text primary key,
  name       text not null,
  created_by uuid references riders(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists members (
  group_code text not null references groups(code) on delete cascade,
  rider_id   uuid not null references riders(id) on delete cascade,
  joined_at  timestamptz not null default now(),
  primary key (group_code, rider_id)
);

create table if not exists tracks (
  id         bigserial primary key,
  rider_id   uuid not null references riders(id) on delete cascade,
  ride       bigint not null,
  pts        jsonb not null,            -- [lat, lng, time, lat, lng, time, ...]
  created_at timestamptz not null default now()
);
create index if not exists tracks_rider_idx on tracks (rider_id);

create table if not exists photos (
  id         bigserial primary key,
  rider_id   uuid not null references riders(id) on delete cascade,
  local_id   bigint not null,
  lat        double precision not null,
  lng        double precision not null,
  t          bigint not null,
  img        text not null,             -- small JPEG, base64
  created_at timestamptz not null default now(),
  unique (rider_id, local_id)
);

alter table riders  enable row level security;
alter table groups  enable row level security;
alter table members enable row level security;
alter table tracks  enable row level security;
alter table photos  enable row level security;
revoke all on riders, groups, members, tracks, photos from anon, authenticated;

-- ---------- helpers ----------
create or replace function tf_check(p_rider uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from riders where id = p_rider and secret = p_secret) then
    raise exception 'Unknown rider';
  end if;
end $$;

create or replace function tf_member(p_rider uuid, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from members where group_code = p_code and rider_id = p_rider) then
    raise exception 'You are not in this group';
  end if;
end $$;

-- ---------- riders ----------
create or replace function register_rider(p_rider uuid, p_secret text, p_name text) returns void
language plpgsql security definer set search_path = public as $$
declare
  existing text;
  clean text := left(coalesce(nullif(trim(p_name), ''), 'Rider'), 30);
begin
  if length(coalesce(p_secret, '')) < 20 then raise exception 'Bad secret'; end if;
  select secret into existing from riders where id = p_rider;
  if existing is null then
    insert into riders (id, secret, name) values (p_rider, p_secret, clean);
  elsif existing = p_secret then
    update riders set name = clean where id = p_rider;
  else
    raise exception 'Unknown rider';
  end if;
end $$;

-- ---------- groups ----------
create or replace function create_group(p_rider uuid, p_secret text, p_name text) returns json
language plpgsql security definer set search_path = public as $$
declare
  c text;
  alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  i int;
  clean text := left(coalesce(nullif(trim(p_name), ''), 'My group'), 40);
begin
  perform tf_check(p_rider, p_secret);
  loop
    c := '';
    for i in 1..6 loop
      c := c || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from groups where code = c);
  end loop;
  insert into groups (code, name, created_by) values (c, clean, p_rider);
  insert into members (group_code, rider_id) values (c, p_rider);
  return json_build_object('code', c, 'name', clean);
end $$;

create or replace function join_group(p_rider uuid, p_secret text, p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare
  g groups;
begin
  perform tf_check(p_rider, p_secret);
  select * into g from groups where code = upper(trim(p_code));
  if not found then raise exception 'No group with that code'; end if;
  insert into members (group_code, rider_id) values (g.code, p_rider) on conflict do nothing;
  return json_build_object('code', g.code, 'name', g.name);
end $$;

create or replace function leave_group(p_rider uuid, p_secret text, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from members where group_code = p_code and rider_id = p_rider;
  delete from groups g where g.code = p_code and not exists (select 1 from members m where m.group_code = g.code);
end $$;

-- ---------- my trails ----------
create or replace function push_track(p_rider uuid, p_secret text, p_chunks jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  insert into tracks (rider_id, ride, pts)
  select p_rider, (c->>'ride')::bigint, c->'pts'
  from jsonb_array_elements(p_chunks) as c
  where jsonb_array_length(c->'pts') >= 3;
end $$;

create or replace function delete_ride(p_rider uuid, p_secret text, p_ride bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from tracks where rider_id = p_rider and ride = p_ride;
end $$;

create or replace function delete_my_tracks(p_rider uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from tracks where rider_id = p_rider;
end $$;

-- ---------- my photos ----------
create or replace function push_photo(p_rider uuid, p_secret text, p_local_id bigint,
  p_lat double precision, p_lng double precision, p_t bigint, p_img text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  if length(p_img) > 2500000 then raise exception 'Photo too large'; end if;
  insert into photos (rider_id, local_id, lat, lng, t, img)
  values (p_rider, p_local_id, p_lat, p_lng, p_t, p_img)
  on conflict (rider_id, local_id) do nothing;
end $$;

create or replace function delete_photo(p_rider uuid, p_secret text, p_local_id bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform tf_check(p_rider, p_secret);
  delete from photos where rider_id = p_rider and local_id = p_local_id;
end $$;

-- ---------- reading a group ----------
-- Returns members, the ids of every trail chunk from other members (so deleted
-- ones can be dropped), up to 200 new chunks after p_since, and photo pins.
create or replace function group_data(p_rider uuid, p_secret text, p_code text, p_since bigint) returns json
language plpgsql security definer set search_path = public as $$
declare
  res json;
begin
  perform tf_check(p_rider, p_secret);
  perform tf_member(p_rider, p_code);
  select json_build_object(
    'group', (select json_build_object('code', g.code, 'name', g.name) from groups g where g.code = p_code),
    'members', coalesce((
      select json_agg(json_build_object('id', r.id, 'name', r.name) order by m.joined_at)
      from members m join riders r on r.id = m.rider_id
      where m.group_code = p_code), '[]'::json),
    'ids', coalesce((
      select json_agg(t.id)
      from tracks t join members m on m.rider_id = t.rider_id
      where m.group_code = p_code and t.rider_id <> p_rider), '[]'::json),
    'tracks', coalesce((
      select json_agg(x order by (x->>'id')::bigint) from (
        select json_build_object('id', t.id, 'rider', t.rider_id, 'ride', t.ride, 'pts', t.pts) as x
        from tracks t join members m on m.rider_id = t.rider_id
        where m.group_code = p_code and t.rider_id <> p_rider and t.id > p_since
        order by t.id
        limit 200) s), '[]'::json),
    'photos', coalesce((
      select json_agg(json_build_object('id', ph.id, 'rider', ph.rider_id, 'lat', ph.lat, 'lng', ph.lng, 't', ph.t) order by ph.t)
      from photos ph join members m on m.rider_id = ph.rider_id
      where m.group_code = p_code and ph.rider_id <> p_rider), '[]'::json)
  ) into res;
  return res;
end $$;

create or replace function get_photo(p_rider uuid, p_secret text, p_code text, p_photo bigint) returns text
language plpgsql security definer set search_path = public as $$
declare
  out_img text;
begin
  perform tf_check(p_rider, p_secret);
  perform tf_member(p_rider, p_code);
  select ph.img into out_img
  from photos ph join members m on m.rider_id = ph.rider_id
  where ph.id = p_photo and m.group_code = p_code;
  if out_img is null then raise exception 'Photo not found'; end if;
  return out_img;
end $$;

-- Only the app-facing functions can be called from the app.
revoke execute on function tf_check(uuid, text), tf_member(uuid, text) from public, anon, authenticated;
grant execute on function
  register_rider(uuid, text, text),
  create_group(uuid, text, text),
  join_group(uuid, text, text),
  leave_group(uuid, text, text),
  push_track(uuid, text, jsonb),
  delete_ride(uuid, text, bigint),
  delete_my_tracks(uuid, text),
  push_photo(uuid, text, bigint, double precision, double precision, bigint, text),
  delete_photo(uuid, text, bigint),
  group_data(uuid, text, text, bigint),
  get_photo(uuid, text, text, bigint)
to anon, authenticated;
