// Importing old rides from GPX files (Strava, Wikiloc, Garmin, Komoot...).
import * as DocumentPicker from 'expo-document-picker';
import { File } from 'expo-file-system';
import * as DB from './db';

function attr(attrs, name) {
  const m = attrs.match(new RegExp('\\b' + name + '\\s*=\\s*["\']([^"\']+)["\']'));
  return m ? parseFloat(m[1]) : NaN;
}

function decode(s) {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&')
    .trim();
}

// Returns { name, pts: [{lat, lng, t}] }. Track points first; route points if there are none.
export function parseGpx(xml) {
  const nameMatch = xml.match(/<trk\b[^>]*>[\s\S]*?<name>([\s\S]*?)<\/name>/) || xml.match(/<name>([\s\S]*?)<\/name>/);
  const name = nameMatch ? decode(nameMatch[1]) : '';
  let pts = [];
  for (const tag of ['trkpt', 'rtept']) {
    const re = new RegExp('<' + tag + '\\b([^>]*?)(?:\\/>|>([\\s\\S]*?)<\\/' + tag + '>)', 'g');
    let m;
    while ((m = re.exec(xml))) {
      const lat = attr(m[1], 'lat');
      const lng = attr(m[1], 'lon');
      if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) continue;
      const tm = (m[2] || '').match(/<time>\s*([^<]+?)\s*<\/time>/);
      pts.push({ lat, lng, t: tm ? Date.parse(tm[1]) : NaN });
    }
    if (pts.length) break;
  }
  // Fill in missing times (2 seconds apart) so the ride still works.
  const anyTime = pts.find((p) => isFinite(p.t));
  let clock = anyTime ? anyTime.t : Date.now() - pts.length * 2000;
  for (const p of pts) {
    if (isFinite(p.t)) clock = p.t;
    else { clock += 2000; p.t = clock; }
  }
  pts = pts.filter((p, i) => i === 0 || p.t >= pts[i - 1].t);
  return { name, pts };
}

// Lets you pick one or more GPX files and adds them as rides.
export async function importGpxFiles() {
  const res = await DocumentPicker.getDocumentAsync({ type: '*/*', multiple: true, copyToCacheDirectory: true });
  if (res.canceled || !res.assets || !res.assets.length) return null;

  const existing = new Set(await DB.rideIds());
  const names = await DB.getJson('rideNames', {});
  const out = { rides: 0, points: 0, skipped: [], duplicates: [] };

  for (const a of res.assets) {
    const label = a.name || 'file';
    let text;
    try { text = await new File(a.uri).text(); } catch { out.skipped.push(label); continue; }
    if (!/<gpx[\s>]/i.test(text)) { out.skipped.push(label); continue; }
    const g = parseGpx(text);
    if (g.pts.length < 2) { out.skipped.push(label); continue; }
    const ride = Math.round(g.pts[0].t);
    if (existing.has(ride)) { out.duplicates.push(label); continue; }
    existing.add(ride);
    await DB.insertPoints(g.pts.map((p) => ({ lat: p.lat, lng: p.lng, t: Math.round(p.t), ride })));
    names[ride] = (g.name || label.replace(/\.gpx$/i, '') || 'Imported ride').slice(0, 60);
    out.rides++;
    out.points += g.pts.length;
  }
  await DB.setJson('rideNames', names);
  return out;
}
