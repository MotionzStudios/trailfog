import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Defs, Mask, Path, Rect } from 'react-native-svg';
import { buildFogPath, pxPerMeter } from './geo';

const FOG_COLOR = '#1A1F27';
const FOG_OPACITY = 0.88;

// Draws a full-screen fog layer with your ridden trails cut out of it.
// The mask is white (fog) everywhere, grey along a soft outer band,
// and black (fully clear) along the trail itself.
export default function FogOverlay({ points, region, width, height, revealM }) {
  const strokePx = useMemo(() => {
    if (!region || !width) return 0;
    return Math.max(4, revealM * 2 * pxPerMeter(region, width));
  }, [region, width, revealM]);

  const d = useMemo(
    () => buildFogPath(points, region, width, height, strokePx),
    [points, region, width, height, strokePx]
  );

  if (!region || !width || !height) return null;

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Svg width={width} height={height}>
        <Defs>
          <Mask id="trails" x="0" y="0" width={width} height={height} maskUnits="userSpaceOnUse">
            <Rect x="0" y="0" width={width} height={height} fill="#ffffff" />
            {d ? (
              <>
                <Path d={d} fill="none" stroke="#7a7a7a" strokeWidth={strokePx * 1.7}
                  strokeLinecap="round" strokeLinejoin="round" />
                <Path d={d} fill="none" stroke="#3a3a3a" strokeWidth={strokePx * 1.3}
                  strokeLinecap="round" strokeLinejoin="round" />
                <Path d={d} fill="none" stroke="#000000" strokeWidth={strokePx}
                  strokeLinecap="round" strokeLinejoin="round" />
              </>
            ) : null}
          </Mask>
        </Defs>
        <Rect x="0" y="0" width={width} height={height}
          fill={FOG_COLOR} fillOpacity={FOG_OPACITY} mask="url(#trails)" />
      </Svg>
    </View>
  );
}
