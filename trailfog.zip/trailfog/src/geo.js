// Pure geometry helpers (no React Native imports, so they can be unit-tested in Node).

export const EARTH_R = 6378137; // metres
const DEG = Math.PI / 180;

// A new trail segment starts when GPS jumps this far or goes quiet this long,
// so the fog doesn't clear in a straight line across land you never rode.
export const MAX_GAP_M = 300;
export const MAX_GAP_MS = 10 * 60 * 1000;

export function mercY(lat) {
  const c = Math.max(-85.05, Math.min(85.05, lat));
  return Math.log(Math.tan(Math.PI / 4 + (c * DEG) / 2));
}

export function distanceM(a, b) {
  const dLat = (b.lat - a.lat) * DEG;
  const dLng = (b.lng - a.lng) * DEG;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(a.lat * DEG) * Math.cos(b.lat * DEG) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_R * Math.asin(Math.min(1, Math.sqrt(s)));
}

// Adds precomputed Mercator coords (mx, my), a segment-break flag (brk)
// and the distance from the previous point (d). `prev` is the last point
// already in the list (or null).
export function enrichSeq(points, prev) {
  const out = [];
  for (const p of points) {
    const q = { ...p, mx: p.lng * DEG, my: mercY(p.lat), brk: true, d: 0 };
    if (prev && prev.ride === p.ride && p.t - prev.t <= MAX_GAP_MS) {
      const d = distanceM(prev, p);
      if (d <= MAX_GAP_M) {
        q.brk = false;
        q.d = d;
      }
    }
    out.push(q);
    prev = q;
  }
  return out;
}

// Pixels per metre at the map centre. Valid while the map is north-up and flat,
// which the app enforces (rotate/pitch disabled).
export function pxPerMeter(region, width) {
  return width / (region.longitudeDelta * DEG) / (EARTH_R * Math.cos(region.latitude * DEG));
}

// Projects lat/lng to screen pixels for a north-up Web Mercator map.
export function makeProjector(region, width, height) {
  const scale = width / (region.longitudeDelta * DEG);
  const cx = region.longitude * DEG;
  const cy = mercY(region.latitude);
  return (mx, my) => {
    let dx = mx - cx;
    if (dx > Math.PI) dx -= 2 * Math.PI;
    else if (dx < -Math.PI) dx += 2 * Math.PI;
    return [width / 2 + dx * scale, height / 2 - (my - cy) * scale];
  };
}

const r1 = (v) => Math.round(v * 10) / 10;

// Builds one SVG path for every ridden segment that touches the screen.
// Points closer than ~1.5px to the last drawn one are skipped, so a huge
// history still produces a small path when zoomed out.
export function buildFogPath(points, region, width, height, marginPx = 0) {
  if (!region || !width || !height || !points.length) return '';
  const project = makeProjector(region, width, height);
  const minX = -marginPx, maxX = width + marginPx;
  const minY = -marginPx, maxY = height + marginPx;
  const inside = (x, y) => x >= minX && x <= maxX && y >= minY && y <= maxY;

  const parts = [];
  let px = 0, py = 0, lastX = 0, lastY = 0;
  let penDown = false;

  for (const p of points) {
    const [x, y] = project(p.mx, p.my);
    if (p.brk) {
      penDown = false;
      if (inside(x, y)) {
        // tiny stroke so a lone point still shows as a round clearing
        parts.push(`M${r1(x)} ${r1(y)}l0.01 0`);
        penDown = true;
        lastX = x; lastY = y;
      }
    } else {
      const offScreen =
        (px < minX && x < minX) || (px > maxX && x > maxX) ||
        (py < minY && y < minY) || (py > maxY && y > maxY);
      if (offScreen) {
        penDown = false;
      } else {
        if (!penDown) {
          parts.push(`M${r1(px)} ${r1(py)}`);
          penDown = true;
          lastX = px; lastY = py;
        }
        const ddx = x - lastX, ddy = y - lastY;
        if (ddx * ddx + ddy * ddy >= 2.25) {
          parts.push(`L${r1(x)} ${r1(y)}`);
          lastX = x; lastY = y;
        }
      }
    }
    px = x; py = y;
  }
  return parts.join('');
}

// ---- "Area uncovered" stat: count unique ~50 m grid cells you've ridden through.
export const CELL_M = 50;
const CELL_DLAT = CELL_M / 111320;

function cellKey(lat, lng) {
  const i = Math.floor(lat / CELL_DLAT);
  const dLng = CELL_DLAT / Math.max(0.01, Math.cos((i + 0.5) * CELL_DLAT * DEG));
  return i + ':' + Math.floor(lng / dLng);
}

export function addCells(set, points, prev) {
  for (const p of points) {
    if (prev && !p.brk && p.d > CELL_M / 2) {
      const n = Math.ceil(p.d / (CELL_M / 2));
      for (let k = 1; k < n; k++) {
        const f = k / n;
        set.add(cellKey(prev.lat + (p.lat - prev.lat) * f, prev.lng + (p.lng - prev.lng) * f));
      }
    }
    set.add(cellKey(p.lat, p.lng));
    prev = p;
  }
  return set;
}

export const cellsToKm2 = (count) => (count * CELL_M * CELL_M) / 1e6;
