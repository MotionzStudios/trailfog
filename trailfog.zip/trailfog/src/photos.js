// Taking, saving and deleting location photos.
import { Alert, Linking } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as IM from 'expo-image-manipulator';
import * as Location from 'expo-location';
import { File, Directory, Paths } from 'expo-file-system';
import { addPhoto, deletePhoto } from './db';

function withTimeout(promise, ms) {
  return Promise.race([promise, new Promise((resolve) => setTimeout(() => resolve(null), ms))]);
}

async function whereAmI() {
  try {
    const pos = await withTimeout(Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }), 8000);
    if (pos) return pos;
  } catch {}
  try {
    return await Location.getLastKnownPositionAsync({ maxAge: 5 * 60 * 1000 });
  } catch {
    return null;
  }
}

// Copies the camera's temporary file into TrailFog's own storage so it is kept.
async function keepFile(srcUri) {
  try {
    const dir = new Directory(Paths.document, 'photos');
    if (!dir.exists) dir.create({ intermediates: true, idempotent: true });
    const dest = new File(dir, 'photo-' + Date.now() + '.jpg');
    await new File(srcUri).copy(dest);
    return dest.uri;
  } catch (e) {
    console.warn('Could not copy photo, using original file', e);
    return srcUri;
  }
}

function openSettingsAlert(title, body) {
  Alert.alert(title, body, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Open settings', onPress: () => Linking.openSettings() },
  ]);
}

// Returns the new photo's id, or null if nothing was saved.
export async function takePhoto() {
  const loc = await Location.requestForegroundPermissionsAsync();
  if (loc.status !== 'granted') {
    openSettingsAlert('Location needed', 'TrailFog needs your location to pin the photo on the map.');
    return null;
  }
  const cam = await ImagePicker.requestCameraPermissionsAsync();
  if (!cam.granted) {
    openSettingsAlert('Camera needed', 'Allow camera access to take photos of places on your rides.');
    return null;
  }

  // Get the position first, while you are standing at the spot.
  const posPromise = whereAmI();
  const shot = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.7 });
  if (shot.canceled || !shot.assets || !shot.assets.length) return null;

  const pos = (await posPromise) || (await whereAmI());
  if (!pos) {
    Alert.alert('No GPS position', 'The photo could not be pinned because your location was not found. Check GPS is on and try again.');
    return null;
  }
  const uri = await keepFile(shot.assets[0].uri);
  return addPhoto({ lat: pos.coords.latitude, lng: pos.coords.longitude, t: Date.now(), uri });
}

export async function removePhoto(photo) {
  try { new File(photo.uri).delete(); } catch {}
  await deletePhoto(photo.id);
}

// A smaller copy (1024 px wide, base64 JPEG) for sharing with your group.
export async function shareImage(uri) {
  const fmt = (IM.SaveFormat && IM.SaveFormat.JPEG) || 'jpeg';
  if (IM.ImageManipulator && IM.ImageManipulator.manipulate) {
    const ref = await IM.ImageManipulator.manipulate(uri).resize({ width: 1024, height: null }).renderAsync();
    const out = await ref.saveAsync({ format: fmt, compress: 0.6, base64: true });
    return out.base64;
  }
  const out = await IM.manipulateAsync(uri, [{ resize: { width: 1024 } }], { compress: 0.6, format: fmt, base64: true });
  return out.base64;
}
