// Group riding: share your cleared trails and photo pins with friends through
// your own free Supabase server (see server/supabase-setup.sql).
import { SUPABASE_URL, SUPABASE_KEY } from './config';
import * as DB from './db';
import { shareImage } from './photos';

export function configured() {
  return /^https:\/\/\S+/.test(SUPABASE_URL) && SUPABASE_KEY.length > 20 && SUPABASE_KEY.indexOf('PASTE_') === -1;
}

async function rpc(fn, args) {
  const headers = { 'Content-Type': 'application/json', apikey: SUPABASE_KEY };
  // Older "anon" keys are JWTs and also go in the Authorization header.
  if (SUPABASE_KEY.startsWith('eyJ')) headers.Authorization = 'Bearer ' + SUPABASE_KEY;
  let res;
  try {
    res = await fetch(SUPABASE_URL.replace(/\/+$/, '') + '/rest/v1/rpc/' + fn, {
      method: 'POST', headers, body: JSON.stringify(args),
    });
  } catch {
    throw new Error('No connection to the group server. Check your signal and try again.');
  }
  const text = await res.text();
  if (!res.ok) {
    let msg = text;
    try { const j = JSON.parse(text); msg = j.message || j.msg || j.error || text; } catch {}
    throw new Error(msg || 'Group server error ' + res.status);
  }
  return text ? JSON.parse(text) : null;
}

function hex(n) {
  let s = '';
  for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 16).toString(16);
  return s;
}
function uuid() {
  const h = hex(32);
  return h.slice(0, 8) + '-' + h.slice(8, 12) + '-4' + h.slice(13, 16) + '-' +
    '89ab'[Math.floor(Math.random() * 4)] + h.slice(17, 20) + '-' + h.slice(20, 32);
}

// This phone's rider identity (made once, kept forever).
export async function me() {
  let id = await DB.getMeta('riderId');
  let secret = await DB.getMeta('riderSecret');
  if (!id || !secret) {
    id = uuid();
    secret = hex(48);
    await DB.setMeta('riderId', id);
    await DB.setMeta('riderSecret', secret);
  }
  return { id, secret, name: (await DB.getMeta('riderName')) || '' };
}

export async function current() {
  const code = await DB.getMeta('groupCode');
  if (!code) return null;
  return { code, name: (await DB.getMeta('groupName')) || 'Group' };
}

async function register(name) {
  const m = await me();
  const clean = String(name || m.name || '').trim().slice(0, 30) || 'Rider';
  await rpc('register_rider', { p_rider: m.id, p_secret: m.secret, p_name: clean });
  await DB.setMeta('riderName', clean);
  return { ...m, name: clean };
}

async function setGroup(g) {
  await DB.setMeta('groupCode', g ? g.code : '');
  await DB.setMeta('groupName', g ? g.name : '');
  await DB.setJson('groupMembers', []);
  await DB.clearRemote();
}

export async function setName(name) {
  return register(name);
}

export async function create(name, groupName) {
  const m = await register(name);
  const g = await rpc('create_group', { p_rider: m.id, p_secret: m.secret, p_name: groupName });
  await setGroup(g);
  return g;
}

export async function join(name, code) {
  const m = await register(name);
  const g = await rpc('join_group', { p_rider: m.id, p_secret: m.secret, p_code: code });
  await setGroup(g);
  return g;
}

export async function leave() {
  const g = await current();
  if (!g) return;
  const m = await me();
  try {
    await rpc('leave_group', { p_rider: m.id, p_secret: m.secret, p_code: g.code });
  } finally {
    await setGroup(null);
  }
}

const dist = (a, b) => {
  const R = 6378137, toRad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * toRad, dLng = (b.lng - a.lng) * toRad;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * toRad) * Math.cos(b.lat * toRad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
};
const r5 = (v) => Math.round(v * 1e5) / 1e5;

// Uploads my new trail points (thinned to ~10 m apart) and new/deleted photos.
export async function push() {
  if (!configured() || !(await current())) return;
  const m = await me();
  let after = Number(await DB.getMeta('pushedPointId')) || 0;
  for (let guard = 0; guard < 200; guard++) {
    const rows = await DB.loadPointsAfter(after, 4000);
    if (!rows.length) break;
    const chunks = [];
    let cur = null, last = null;
    for (const r of rows) {
      if (!cur || cur.ride !== r.ride || cur.pts.length >= 4500) {
        cur = { ride: r.ride, pts: [] };
        chunks.push(cur);
        last = null;
      }
      if (last && dist(last, r) < 10 && r.t - last.t < 10 * 60 * 1000) continue;
      cur.pts.push(r5(r.lat), r5(r.lng), r.t);
      last = r;
    }
    await rpc('push_track', { p_rider: m.id, p_secret: m.secret, p_chunks: chunks.filter((c) => c.pts.length >= 3) });
    after = rows[rows.length - 1].id;
    await DB.setMeta('pushedPointId', after);
  }

  const pushed = new Set(await DB.getJson('pushedPhotos', []));
  const local = await DB.loadPhotos();
  const localIds = new Set(local.map((p) => p.id));
  for (const p of local) {
    if (pushed.has(p.id)) continue;
    try {
      const img = await shareImage(p.uri);
      await rpc('push_photo', { p_rider: m.id, p_secret: m.secret, p_local_id: p.id, p_lat: p.lat, p_lng: p.lng, p_t: p.t, p_img: img });
      pushed.add(p.id);
      await DB.setJson('pushedPhotos', [...pushed]);
    } catch (e) {
      console.warn('Photo upload failed', e);
    }
  }
  for (const id of [...pushed]) {
    if (localIds.has(id)) continue;
    try {
      await rpc('delete_photo', { p_rider: m.id, p_secret: m.secret, p_local_id: id });
      pushed.delete(id);
    } catch {}
  }
  await DB.setJson('pushedPhotos', [...pushed]);
}

export async function deleteRide(ride) {
  if (!configured()) return;
  const m = await me();
  if (!(await DB.getMeta('riderName'))) return; // never registered: nothing on the server
  await rpc('delete_ride', { p_rider: m.id, p_secret: m.secret, p_ride: ride });
}

export async function deleteAllMine() {
  if (!configured()) return;
  const m = await me();
  if (!(await DB.getMeta('riderName'))) return;
  await rpc('delete_my_tracks', { p_rider: m.id, p_secret: m.secret });
}

// Downloads other riders' new trails. Returns { changed, members, photos, meId }.
export async function pull() {
  const g = await current();
  if (!configured() || !g) return null;
  const m = await me();
  let since = await DB.maxRemoteId();
  let changed = false, info = null;
  for (let guard = 0; guard < 100; guard++) {
    const res = await rpc('group_data', { p_rider: m.id, p_secret: m.secret, p_code: g.code, p_since: since });
    if (!info) {
      info = res;
      if ((await DB.deleteRemoteNotIn(res.ids || [])) > 0) changed = true;
    }
    const tracks = res.tracks || [];
    if (tracks.length) {
      await DB.saveRemoteChunks(tracks);
      since = Math.max(since, ...tracks.map((t) => t.id));
      changed = true;
    }
    if (tracks.length < 200) break;
  }
  if (info.group && info.group.name) await DB.setMeta('groupName', info.group.name);
  const members = info.members || [];
  const before = JSON.stringify(await DB.getJson('groupMembers', []));
  if (before !== JSON.stringify(members)) { await DB.setJson('groupMembers', members); changed = true; }
  const photos = info.photos || [];
  const photoKey = JSON.stringify(photos.map((p) => p.id));
  if (photoKey !== (await DB.getMeta('groupPhotoKey'))) { await DB.setMeta('groupPhotoKey', photoKey); changed = true; }
  return { changed, members, photos, meId: m.id };
}

export async function getPhoto(id) {
  const g = await current();
  const m = await me();
  return rpc('get_photo', { p_rider: m.id, p_secret: m.secret, p_code: g.code, p_photo: id });
}
