// Sign in with Apple (iPhone) or Google (both), through Supabase Auth.
// Signing in links this phone's rider to the account, so a new phone gets the
// same rider (name, groups, leaderboard place) back.
import { Platform } from 'react-native';
import * as AppleAuthentication from 'expo-apple-authentication';
import * as WebBrowser from 'expo-web-browser';
import * as Crypto from 'expo-crypto';
import * as Linking from 'expo-linking';
import { SUPABASE_URL, SUPABASE_KEY } from './config';
import * as DB from './db';

const BASE = () => SUPABASE_URL.replace(/\/+$/, '');

export async function account() {
  return DB.getJson('account', null); // { provider, email } or null
}

export async function appleAvailable() {
  if (Platform.OS !== 'ios') return false;
  try { return await AppleAuthentication.isAvailableAsync(); } catch { return false; }
}

async function authFetch(path, body) {
  let res;
  try {
    res = await fetch(BASE() + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error('No connection. Check your signal and try again.');
  }
  const text = await res.text();
  let j = null;
  try { j = text ? JSON.parse(text) : null; } catch {}
  if (!res.ok) throw new Error((j && (j.msg || j.message || j.error_description || j.error)) || 'Sign-in failed (' + res.status + ')');
  return j;
}

function randomString(n) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = Crypto.getRandomBytes(n);
  let s = '';
  for (let i = 0; i < n; i++) s += chars[bytes[i] % chars.length];
  return s;
}

// Returns { token, email, provider, fullName } or null if the rider cancelled.
async function apple() {
  const raw = randomString(32);
  const hashed = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, raw);
  let cred;
  try {
    cred = await AppleAuthentication.signInAsync({
      requestedScopes: [AppleAuthentication.AppleAuthenticationScope.FULL_NAME, AppleAuthentication.AppleAuthenticationScope.EMAIL],
      nonce: hashed,
    });
  } catch (e) {
    if (e && e.code === 'ERR_REQUEST_CANCELED') return null;
    throw e;
  }
  if (!cred.identityToken) throw new Error('Apple did not return a sign-in token.');
  const j = await authFetch('/auth/v1/token?grant_type=id_token', { provider: 'apple', id_token: cred.identityToken, nonce: raw });
  const fullName = cred.fullName ? [cred.fullName.givenName, cred.fullName.familyName].filter(Boolean).join(' ') : '';
  return { token: j.access_token, email: (j.user && j.user.email) || cred.email || '', provider: 'apple', fullName };
}

async function google() {
  const redirect = Linking.createURL('auth');
  const url = BASE() + '/auth/v1/authorize?provider=google&redirect_to=' + encodeURIComponent(redirect);
  const r = await WebBrowser.openAuthSessionAsync(url, redirect);
  if (r.type !== 'success' || !r.url) return null;
  const frag = r.url.split('#')[1] || r.url.split('?')[1] || '';
  const params = {};
  frag.split('&').forEach((kv) => {
    const i = kv.indexOf('=');
    if (i > 0) params[decodeURIComponent(kv.slice(0, i))] = decodeURIComponent(kv.slice(i + 1).replace(/\+/g, ' '));
  });
  if (params.error) throw new Error(params.error_description || params.error);
  if (!params.access_token) throw new Error('Google sign-in did not finish. Try again.');
  let email = '';
  try {
    const payload = JSON.parse(atob(params.access_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    email = payload.email || '';
  } catch {}
  return { token: params.access_token, email, provider: 'google', fullName: '' };
}

// Signs in and links the rider. `claim(token)` is given by group.js and returns the rider record.
export async function signIn(provider, claim) {
  const s = provider === 'apple' ? await apple() : await google();
  if (!s) return null;
  const rider = await claim(s.token);
  await DB.setJson('account', { provider: s.provider, email: s.email });
  return { ...s, rider };
}

export async function forget() {
  await DB.setJson('account', null);
}
