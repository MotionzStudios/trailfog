// Filters raw phone positions so only believable GPS points become trail.
// Pure logic (no phone APIs) so it can be tested anywhere.

const R = 6378137, RAD = Math.PI / 180;
export function dist(a, b) {
  const dLat = (b.lat - a.lat) * RAD, dLng = (b.lng - a.lng) * RAD;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export const MAX_ACCURACY_M = 20;   // GPS outdoors is usually 3-10 m; Wi-Fi / mast positions are worse
const MIN_STEP_M = 4;               // ignore jitter while standing still
const MAX_SPEED_MS = 70;            // ~250 km/h
const JUMP_M = 150;                 // a sudden move further than this needs confirming
const CONFIRM = 3;                  // ...by this many positions that agree with each other
const LONG_PAUSE_MS = 10 * 60 * 1000;

export function createFilter() {
  return { last: null, pending: [] };
}

// Feed one position { lat, lng, t, acc }. Returns the points to save (often none).
export function feed(state, p) {
  if (p.acc != null && p.acc > MAX_ACCURACY_M) return [];
  const last = state.last;
  if (!last) { state.last = p; return [p]; }

  const d = dist(last, p), dt = (p.t - last.t) / 1000;
  if (dt <= 0) return [];

  // After a long pause (phone off, tunnel, new ride) just start fresh from here.
  if (p.t - last.t >= LONG_PAUSE_MS) { state.pending = []; state.last = p; return [p]; }

  if (d > JUMP_M) {
    // Doesn't fit the trail so far: hold it until more positions agree.
    const prev = state.pending.length ? state.pending[state.pending.length - 1] : null;
    if (prev) {
      const pd = dist(prev, p), pdt = (p.t - prev.t) / 1000;
      if (pdt <= 0 || pd / pdt > MAX_SPEED_MS || pd > Math.max(60, MAX_SPEED_MS * pdt)) state.pending = [];
    }
    state.pending.push(p);
    if (state.pending.length >= CONFIRM) {
      const ok = state.pending;
      state.pending = [];
      state.last = ok[ok.length - 1];
      return ok;
    }
    return [];
  }

  // Back near the trail: whatever was pending was a glitch.
  state.pending = [];
  if (d < MIN_STEP_M) return [];
  if (d / dt > MAX_SPEED_MS) return [];
  state.last = p;
  return [p];
}

// For the live "you are here" dot: should this position move the dot?
export function liveDotOk(lastGood, p) {
  if (!lastGood) return true;
  const fresh = p.t - lastGood.t < 30000;
  if (!fresh) return true;
  if (p.acc != null && p.acc > 50 && (lastGood.acc || 0) <= 30) return false;
  if (dist(lastGood, p) > JUMP_M && (p.acc || 0) > 2 * Math.max(lastGood.acc || 0, 10)) return false;
  return true;
}
