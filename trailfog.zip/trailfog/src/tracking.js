import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { addPoints, getMeta, setMeta, setJson } from './db';
import { createFilter, feed } from './gpsfilter';

export const TASK = 'trailfog-background-location';

const listeners = new Set();
let filter = createFilter();   // drops rough Wi-Fi/mast positions and one-off jumps (see gpsfilter.js)
let currentRide = null;

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function resetLastPoint() {
  filter = createFilter();
}

// Runs whenever the OS hands us new locations — including with the screen off.
TaskManager.defineTask(TASK, async ({ data, error }) => {
  if (error || !data) return;
  try {
    if (currentRide == null) currentRide = Number((await getMeta('currentRide')) || Date.now());
    const accepted = [];
    for (const loc of data.locations || []) {
      const { latitude, longitude, accuracy } = loc.coords;
      if (loc.mocked || loc.coords.mocked) continue;   // position from a "fake GPS" app
      const p = { lat: latitude, lng: longitude, t: Math.round(loc.timestamp), acc: accuracy };
      for (const ok of feed(filter, p)) {
        accepted.push({ lat: ok.lat, lng: ok.lng, t: ok.t, ride: currentRide });
      }
    }
    if (accepted.length) {
      await addPoints(accepted);
      listeners.forEach((fn) => fn(accepted));
    }
    // GPS quality for this ride, shown in Settings (helps work out trail gaps).
    if (filter.stats && filter.stats.seen % 20 < (data.locations || []).length) {
      await setJson('gpsStats', { ride: currentRide, ...filter.stats });
    }
  } catch (e) {
    console.warn('TrailFog location task failed', e);
  }
});

export async function isRiding() {
  try {
    return await Location.hasStartedLocationUpdatesAsync(TASK);
  } catch {
    return false;
  }
}

// Returns 'ok', 'denied' (no location at all) or 'no-background' (only "while using").
export async function requestPermissions() {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return 'denied';
  const bg = await Location.requestBackgroundPermissionsAsync();
  return bg.status === 'granted' ? 'ok' : 'no-background';
}

export async function startRide() {
  currentRide = Date.now();
  filter = createFilter();
  await setMeta('currentRide', currentRide);
  await Location.startLocationUpdatesAsync(TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    distanceInterval: 5,
    timeInterval: 2000,
    activityType: Location.ActivityType.OtherNavigation,
    pausesUpdatesAutomatically: false,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'TrailFog is mapping your ride',
      notificationBody: 'Clearing the fog along your trail.',
      notificationColor: '#E8362B',
      killServiceOnDestroy: false,
    },
  });
  return currentRide;
}

export async function stopRide() {
  if (await isRiding()) await Location.stopLocationUpdatesAsync(TASK);
}

export async function getCurrentRideId() {
  if (currentRide != null) return currentRide;
  const v = await getMeta('currentRide');
  return v ? Number(v) : null;
}
