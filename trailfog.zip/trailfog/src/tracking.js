import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { addPoints, getMeta, setMeta } from './db';
import { distanceM } from './geo';

export const TASK = 'trailfog-background-location';

const MAX_ACCURACY_M = 35;   // ignore fuzzy GPS fixes
const MIN_STEP_M = 4;        // don't store a new point until you've moved this far
const MAX_SPEED_MS = 70;     // ~250 km/h: anything faster is a GPS glitch

const listeners = new Set();
let lastSaved = null;
let currentRide = null;

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function resetLastPoint() {
  lastSaved = null;
}

// Runs whenever the OS hands us new locations — including with the screen off.
TaskManager.defineTask(TASK, async ({ data, error }) => {
  if (error || !data) return;
  try {
    if (currentRide == null) currentRide = Number((await getMeta('currentRide')) || Date.now());
    const accepted = [];
    for (const loc of data.locations || []) {
      const { latitude, longitude, accuracy } = loc.coords;
      if (loc.mocked || loc.coords.mocked) continue;   // position from a "fake GPS" app
      if (accuracy != null && accuracy > MAX_ACCURACY_M) continue;
      const p = { lat: latitude, lng: longitude, t: Math.round(loc.timestamp), ride: currentRide };
      if (lastSaved && lastSaved.ride === p.ride) {
        const d = distanceM(lastSaved, p);
        if (d < MIN_STEP_M) continue;
        const dt = (p.t - lastSaved.t) / 1000;
        if (dt > 0 && d / dt > MAX_SPEED_MS) continue;
      }
      accepted.push(p);
      lastSaved = p;
    }
    if (accepted.length) {
      await addPoints(accepted);
      listeners.forEach((fn) => fn(accepted));
    }
  } catch (e) {
    console.warn('TrailFog location task failed', e);
  }
});

export async function isRiding() {
  try {
    return await Location.hasStartedLocationUpdatesAsync(TASK);
  } catch {
    return false;
  }
}

// Returns 'ok', 'denied' (no location at all) or 'no-background' (only "while using").
export async function requestPermissions() {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return 'denied';
  const bg = await Location.requestBackgroundPermissionsAsync();
  return bg.status === 'granted' ? 'ok' : 'no-background';
}

export async function startRide() {
  currentRide = Date.now();
  lastSaved = null;
  await setMeta('currentRide', currentRide);
  await Location.startLocationUpdatesAsync(TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    distanceInterval: 5,
    timeInterval: 2000,
    activityType: Location.ActivityType.OtherNavigation,
    pausesUpdatesAutomatically: false,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'TrailFog is mapping your ride',
      notificationBody: 'Clearing the fog along your trail.',
      notificationColor: '#F2A93B',
      killServiceOnDestroy: false,
    },
  });
  return currentRide;
}

export async function stopRide() {
  if (await isRiding()) await Location.stopLocationUpdatesAsync(TASK);
}

export async function getCurrentRideId() {
  if (currentRide != null) return currentRide;
  const v = await getMeta('currentRide');
  return v ? Number(v) : null;
}
