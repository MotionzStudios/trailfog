import * as SQLite from 'expo-sqlite';

let dbPromise = null;

export function getDb() {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('trailfog.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS points (
          id   INTEGER PRIMARY KEY AUTOINCREMENT,
          lat  REAL NOT NULL,
          lng  REAL NOT NULL,
          t    INTEGER NOT NULL,
          ride INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS points_ride ON points (ride);
        CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
        CREATE TABLE IF NOT EXISTS photos (
          id   INTEGER PRIMARY KEY AUTOINCREMENT,
          lat  REAL NOT NULL,
          lng  REAL NOT NULL,
          t    INTEGER NOT NULL,
          uri  TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS remote_chunks (
          id    INTEGER PRIMARY KEY,
          rider TEXT NOT NULL,
          ride  INTEGER,
          pts   TEXT NOT NULL
        );
      `);
      return db;
    })();
  }
  return dbPromise;
}

// ---------- my GPS points ----------
export async function addPoints(points) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    for (const p of points) {
      await db.runAsync('INSERT INTO points (lat, lng, t, ride) VALUES (?, ?, ?, ?)', p.lat, p.lng, p.t, p.ride);
    }
  });
}

// Fast insert for big imports (GPX files).
export async function insertPoints(points) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const st = await db.prepareAsync('INSERT INTO points (lat, lng, t, ride) VALUES (?, ?, ?, ?)');
    try {
      for (const p of points) await st.executeAsync([p.lat, p.lng, p.t, p.ride]);
    } finally {
      await st.finalizeAsync();
    }
  });
}

export async function loadPoints() {
  const db = await getDb();
  return db.getAllAsync('SELECT id, lat, lng, t, ride FROM points ORDER BY id');
}

export async function loadPointsAfter(id, limit) {
  const db = await getDb();
  return db.getAllAsync('SELECT id, lat, lng, t, ride FROM points WHERE id > ? ORDER BY id LIMIT ?', id, limit);
}

export async function loadPointsUpTo(id) {
  const db = await getDb();
  return db.getAllAsync('SELECT id, lat, lng, t, ride FROM points WHERE id <= ? ORDER BY id', id);
}

export async function getPoint(id) {
  const db = await getDb();
  return db.getFirstAsync('SELECT id, lat, lng, t, ride FROM points WHERE id = ?', id);
}

export async function rideIds() {
  const db = await getDb();
  const rows = await db.getAllAsync('SELECT DISTINCT ride FROM points');
  return rows.map((r) => r.ride);
}

export async function deleteRide(ride) {
  const db = await getDb();
  await db.runAsync('DELETE FROM points WHERE ride = ?', ride);
}

export async function clearPoints() {
  const db = await getDb();
  await db.runAsync('DELETE FROM points');
}

// ---------- photos ----------
export async function addPhoto(p) {
  const db = await getDb();
  const r = await db.runAsync('INSERT INTO photos (lat, lng, t, uri) VALUES (?, ?, ?, ?)', p.lat, p.lng, p.t, p.uri);
  return r.lastInsertRowId;
}

export async function loadPhotos() {
  const db = await getDb();
  return db.getAllAsync('SELECT id, lat, lng, t, uri FROM photos ORDER BY t');
}

export async function deletePhoto(id) {
  const db = await getDb();
  await db.runAsync('DELETE FROM photos WHERE id = ?', id);
}

// ---------- group riders' trails (downloaded copy) ----------
export async function saveRemoteChunks(chunks) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    for (const c of chunks) {
      await db.runAsync('INSERT OR REPLACE INTO remote_chunks (id, rider, ride, pts) VALUES (?, ?, ?, ?)',
        c.id, c.rider, c.ride, JSON.stringify(c.pts));
    }
  });
}

export async function loadRemoteChunks() {
  const db = await getDb();
  const rows = await db.getAllAsync('SELECT id, rider, ride, pts FROM remote_chunks ORDER BY id');
  return rows.map((r) => ({ id: r.id, rider: r.rider, ride: r.ride, pts: JSON.parse(r.pts) }));
}

export async function maxRemoteId() {
  const db = await getDb();
  const r = await db.getFirstAsync('SELECT MAX(id) AS m FROM remote_chunks');
  return (r && r.m) || 0;
}

// Drops downloaded chunks the server no longer has. Returns how many were removed.
export async function deleteRemoteNotIn(ids) {
  const db = await getDb();
  const r = await db.runAsync('DELETE FROM remote_chunks WHERE id NOT IN (SELECT value FROM json_each(?))', JSON.stringify(ids));
  return r.changes || 0;
}

export async function clearRemote() {
  const db = await getDb();
  await db.runAsync('DELETE FROM remote_chunks');
}

// ---------- settings ----------
export async function getMeta(k) {
  const db = await getDb();
  const row = await db.getFirstAsync('SELECT v FROM meta WHERE k = ?', k);
  return row ? row.v : null;
}

export async function setMeta(k, v) {
  const db = await getDb();
  await db.runAsync('INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)', k, String(v));
}

export async function getJson(k, fallback) {
  const v = await getMeta(k);
  if (v == null || v === '') return fallback;
  try { return JSON.parse(v); } catch { return fallback; }
}

export async function setJson(k, v) {
  await setMeta(k, JSON.stringify(v));
}
