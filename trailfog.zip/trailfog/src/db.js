import * as SQLite from 'expo-sqlite';

let dbPromise = null;

export function getDb() {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('trailfog.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS points (
          id   INTEGER PRIMARY KEY AUTOINCREMENT,
          lat  REAL NOT NULL,
          lng  REAL NOT NULL,
          t    INTEGER NOT NULL,
          ride INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
      `);
      return db;
    })();
  }
  return dbPromise;
}

export async function addPoints(points) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    for (const p of points) {
      await db.runAsync('INSERT INTO points (lat, lng, t, ride) VALUES (?, ?, ?, ?)', p.lat, p.lng, p.t, p.ride);
    }
  });
}

export async function loadPoints() {
  const db = await getDb();
  return db.getAllAsync('SELECT lat, lng, t, ride FROM points ORDER BY id');
}

export async function clearPoints() {
  const db = await getDb();
  await db.runAsync('DELETE FROM points');
}

export async function getMeta(k) {
  const db = await getDb();
  const row = await db.getFirstAsync('SELECT v FROM meta WHERE k = ?', k);
  return row ? row.v : null;
}

export async function setMeta(k, v) {
  const db = await getDb();
  await db.runAsync('INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)', k, String(v));
}
