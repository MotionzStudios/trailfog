// Start-up safety net: if anything goes wrong in the app's code, show the error
// on screen (so it can be screenshotted) instead of letting the app close.
import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

const errors = [];
const listeners = new Set();
function report(e, where) {
  const stack = e && e.stack ? String(e.stack).split('\n').slice(0, 8).join('\n') : '';
  errors.push('[' + where + '] ' + (e && e.message ? e.message : String(e)) + '\n' + stack);
  listeners.forEach((fn) => fn([...errors]));
}

if (global.ErrorUtils) {
  global.ErrorUtils.setGlobalHandler((e, isFatal) => report(e, isFatal ? 'fatal' : 'error'));
}

// The background GPS task has to be registered as soon as the app starts.
try {
  require('./tracking');
} catch (e) {
  report(e, 'loading tracking');
}

let App = null;
try {
  App = require('../App').default;
} catch (e) {
  report(e, 'loading app');
}

class Catch extends React.Component {
  constructor(props) { super(props); this.state = { failed: false }; }
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(e) { report(e, 'screen'); }
  render() { return this.state.failed ? null : this.props.children; }
}

export default function Boot() {
  const [errs, setErrs] = useState([...errors]);
  useEffect(() => {
    listeners.add(setErrs);
    return () => listeners.delete(setErrs);
  }, []);

  if (errs.length || !App) {
    return (
      <View style={s.root}>
        <Text style={s.title}>TrailFog hit a problem</Text>
        <Text style={s.sub}>Screenshot this screen and send it to Claude.</Text>
        <ScrollView style={s.box}>
          <Text selectable style={s.err}>{errs.join('\n\n')}</Text>
        </ScrollView>
      </View>
    );
  }
  return (
    <Catch>
      <App />
    </Catch>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1F27', padding: 24, paddingTop: 60 },
  title: { color: '#F4F6F8', fontSize: 22, fontWeight: '800' },
  sub: { color: '#A7B0BC', fontSize: 14, marginTop: 6, marginBottom: 16 },
  box: { flex: 1, backgroundColor: '#0E1116', borderRadius: 12, padding: 12 },
  err: { color: '#FF8A80', fontSize: 12, fontFamily: 'monospace' },
});
