// Start-up safety net: shows any error on screen instead of letting the app close,
// and lets you open TrailFog with or without the map to find what is crashing.
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

const errors = [];
const listeners = new Set();
function report(e, where) {
  const msg = `[${where}] ${e && e.message ? e.message : String(e)}\n${e && e.stack ? String(e.stack).split('\n').slice(0, 8).join('\n') : ''}`;
  errors.push(msg);
  listeners.forEach((fn) => fn([...errors]));
}

// Catch any JavaScript error anywhere in the app and keep it on screen.
if (global.ErrorUtils) {
  global.ErrorUtils.setGlobalHandler((e, isFatal) => report(e, isFatal ? 'fatal' : 'error'));
}

// Background GPS task must be registered at start-up.
try {
  require('./tracking');
} catch (e) {
  report(e, 'loading tracking');
}

class Catch extends React.Component {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(e) { report(e, 'screen'); }
  render() { return this.state.failed ? null : this.props.children; }
}

export default function Boot() {
  const [errs, setErrs] = useState([...errors]);
  const [mode, setMode] = useState(null); // null | 'map' | 'nomap'
  const [App, setApp] = useState(null);

  useEffect(() => {
    listeners.add(setErrs);
    return () => listeners.delete(setErrs);
  }, []);

  function open(m) {
    try {
      const A = require('../App').default;
      setApp(() => A);
      setMode(m);
    } catch (e) {
      report(e, 'loading app');
    }
  }

  if (errs.length) {
    return (
      <View style={s.root}>
        <Text style={s.title}>TrailFog hit a problem</Text>
        <Text style={s.sub}>Screenshot this screen and send it to Claude.</Text>
        <ScrollView style={s.box}>
          <Text selectable style={s.err}>{errs.join('\n\n')}</Text>
        </ScrollView>
      </View>
    );
  }

  if (App && mode) {
    return (
      <Catch>
        <App noMap={mode === 'nomap'} />
      </Catch>
    );
  }

  return (
    <View style={[s.root, { justifyContent: 'center' }]}>
      <Text style={s.brand}>TRAILFOG</Text>
      <Text style={s.sub}>Test version</Text>
      <Pressable style={s.btn} onPress={() => open('map')}>
        <Text style={s.btnText}>Open with map</Text>
      </Pressable>
      <Pressable style={[s.btn, s.btn2]} onPress={() => open('nomap')}>
        <Text style={[s.btnText, { color: '#F2A93B' }]}>Open without map</Text>
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1F27', padding: 24, paddingTop: 60 },
  brand: { color: '#F2A93B', fontSize: 28, fontWeight: '800', letterSpacing: 4, textAlign: 'center' },
  title: { color: '#F4F6F8', fontSize: 22, fontWeight: '800' },
  sub: { color: '#A7B0BC', fontSize: 14, marginTop: 6, marginBottom: 24, textAlign: 'center' },
  box: { flex: 1, backgroundColor: '#0E1116', borderRadius: 12, padding: 12 },
  err: { color: '#FF8A80', fontSize: 12, fontFamily: 'monospace' },
  btn: { backgroundColor: '#F2A93B', height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', marginTop: 12 },
  btn2: { backgroundColor: 'transparent', borderWidth: 2, borderColor: '#F2A93B' },
  btnText: { color: '#1A1F27', fontSize: 17, fontWeight: '800' },
});
