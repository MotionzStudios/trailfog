// Offline maps: download the map pictures (tiles) for an area so it shows with no signal.
import { File, Directory, Paths } from 'expo-file-system';
import * as DB from './db';

let expoFetch = null;
try { expoFetch = require('expo/fetch').fetch; } catch {}

const UA = 'TrailFog/1.2 (personal trail-riding app)';
export const MAX_TILES = 2500;

const URLS = {
  topo: (z, x, y) => 'https://' + 'abc'[(x + y) % 3] + '.tile.opentopomap.org/' + z + '/' + x + '/' + y + '.png',
  sat: (z, x, y) => 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/' + z + '/' + y + '/' + x,
};

const lon2x = (lng, z) => Math.floor(((lng + 180) / 360) * Math.pow(2, z));
const lat2y = (lat, z) => {
  const r = Math.max(-85.05, Math.min(85.05, lat)) * Math.PI / 180;
  return Math.floor(((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * Math.pow(2, z));
};

export function tilesFor(area) {
  const [w, s, e, n] = area.bbox;
  const out = [];
  for (let z = area.zmin; z <= area.zmax; z++) {
    const x0 = lon2x(w, z), x1 = lon2x(e, z), y0 = lat2y(n, z), y1 = lat2y(s, z);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) out.push({ z, x, y });
  }
  return out;
}

function tileFile(layer, z, x, y) {
  return new File(Paths.document, 'tiles', layer, String(z), String(x), y + '.png');
}

async function download(layer, t) {
  const f = tileFile(layer, t.z, t.x, t.y);
  if (f.exists) return f.size || 0;
  const dir = new Directory(Paths.document, 'tiles', layer, String(t.z), String(t.x));
  if (!dir.exists) dir.create({ intermediates: true, idempotent: true });
  const doFetch = expoFetch || fetch;
  const res = await doFetch(URLS[layer](t.z, t.x, t.y), { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (!f.exists) f.create();
  f.write(bytes);
  return bytes.length;
}

export async function areas() {
  return DB.getJson('offlineAreas', []);
}

let job = null;

export function cancel() {
  if (job) job.cancelled = true;
}

export function busy() {
  return !!job;
}

// Downloads an area. onProgress({ done, total, failed, bytes }) is called as it goes.
export async function downloadArea(req, onProgress) {
  if (job) throw new Error('A download is already running.');
  const area = {
    id: Date.now(),
    name: 'Area near ' + ((req.bbox[1] + req.bbox[3]) / 2).toFixed(3) + ', ' + ((req.bbox[0] + req.bbox[2]) / 2).toFixed(3),
    layer: req.layer === 'sat' ? 'sat' : 'topo',
    bbox: req.bbox,
    zmin: req.zmin,
    zmax: req.zmax,
    date: Date.now(),
  };
  const tiles = tilesFor(area);
  if (tiles.length > MAX_TILES) throw new Error('That area is too big. Zoom in and try again.');
  job = { cancelled: false };
  const state = { done: 0, total: tiles.length, failed: 0, bytes: 0 };
  let next = 0, lastReport = 0;
  const worker = async () => {
    while (!job.cancelled && next < tiles.length) {
      const t = tiles[next++];
      try { state.bytes += await download(area.layer, t); } catch { state.failed++; }
      state.done++;
      if (state.done - lastReport >= 20 || state.done === state.total) {
        lastReport = state.done;
        onProgress({ ...state });
      }
    }
  };
  try {
    await Promise.all([worker(), worker(), worker(), worker()]);
    const cancelled = job.cancelled;
    if (!cancelled) {
      area.tiles = tiles.length - state.failed;
      area.bytes = state.bytes;
      const list = await areas();
      list.push(area);
      await DB.setJson('offlineAreas', list);
    }
    return { ...state, cancelled, area };
  } finally {
    job = null;
  }
}

export async function deleteArea(id) {
  const list = await areas();
  const area = list.find((a) => a.id === id);
  if (!area) return;
  const rest = list.filter((a) => a.id !== id);
  const keep = new Set();
  for (const a of rest) if (a.layer === area.layer) for (const t of tilesFor(a)) keep.add(t.z + '/' + t.x + '/' + t.y);
  for (const t of tilesFor(area)) {
    if (keep.has(t.z + '/' + t.x + '/' + t.y)) continue;
    try { const f = tileFile(area.layer, t.z, t.x, t.y); if (f.exists) f.delete(); } catch {}
  }
  await DB.setJson('offlineAreas', rest);
}

// Returns a saved tile as base64, or null if it isn't on the phone.
export async function readTile(key) {
  const [layer, z, x, y] = key.split('/');
  try {
    const f = tileFile(layer, z, x, y);
    if (!f.exists) return null;
    return await f.base64();
  } catch {
    return null;
  }
}
