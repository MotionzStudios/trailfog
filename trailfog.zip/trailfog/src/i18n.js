// App text in the rider's language. Strings are keyed by their English text, so a missing
// translation just shows English. The map page uses the same files (see scripts/build-map.js).
import * as Localization from 'expo-localization';
import es from './i18n/es.json';
import fr from './i18n/fr.json';
import de from './i18n/de.json';
import it from './i18n/it.json';
import pt from './i18n/pt.json';
import nl from './i18n/nl.json';
import pl from './i18n/pl.json';
import lv from './i18n/lv.json';

const DICT = { es, fr, de, it, pt, nl, pl, lv };

export function deviceLang() {
  try {
    const l = Localization.getLocales()[0];
    return String((l && l.languageCode) || 'en').toLowerCase();
  } catch {
    return 'en';
  }
}

let lang = 'en';
// override: a language code chosen in Settings, or '' to follow the phone.
export function setLang(override) {
  const c = String(override || deviceLang()).slice(0, 2).toLowerCase();
  lang = DICT[c] ? c : 'en';
  return lang;
}
export function getLang() { return lang; }
setLang('');

// Marks a string for translation where it is translated later (e.g. passed on, then t()'d).
t.key = (s) => s;

export function t(s, vars) {
  const d = DICT[lang];
  let r = (d && d[s]) || s;
  if (vars) r = r.replace(/\{(\w+)\}/g, (m, k) => (Object.prototype.hasOwnProperty.call(vars, k) ? String(vars[k]) : m));
  return r;
}
