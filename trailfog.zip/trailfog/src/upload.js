// Pure helpers for uploading trails (no phone APIs, so they can be tested anywhere).

const R = 6378137, RAD = Math.PI / 180;
export const MAX_GAP_M = 300, MAX_GAP_MS = 10 * 60 * 1000;
const CELL_M = 50, CELL_DLAT = CELL_M / 111320;

export function dist(a, b) {
  const dLat = (b.lat - a.lat) * RAD, dLng = (b.lng - a.lng) * RAD;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export function inZone(zones, p) {
  for (const z of zones || []) if (dist(z, p) <= z.r) return true;
  return false;
}

// Same 50 m grid the map uses for "km² uncovered".
export function cellKey(lat, lng) {
  const i = Math.floor(lat / CELL_DLAT);
  const dLng = CELL_DLAT / Math.max(0.01, Math.cos((i + 0.5) * CELL_DLAT * RAD));
  return i + ':' + Math.floor(lng / dLng);
}

function joined(a, b) {
  return a && b && a.ride === b.ride && b.t - a.t <= MAX_GAP_MS && b.t >= a.t && dist(a, b) <= MAX_GAP_M;
}

// Adds the cells along a -> b to `seen`; returns how many were new.
function addCells(seen, a, b) {
  let added = 0;
  const add = (lat, lng) => { const k = cellKey(lat, lng); if (!seen.has(k)) { seen.add(k); added++; } };
  if (a && joined(a, b)) {
    const d = dist(a, b), n = Math.ceil(d / (CELL_M / 2));
    for (let k = 1; k < n; k++) add(a.lat + (b.lat - a.lat) * k / n, a.lng + (b.lng - a.lng) * k / n);
  }
  add(b.lat, b.lng);
  return added;
}

// Builds the "seen" cell set from points already uploaded (skipping privacy zones).
export function seenCells(rows, zones) {
  const seen = new Set();
  let prev = null;
  for (const r of rows) {
    if (inZone(zones, r)) { prev = null; continue; }
    addCells(seen, prev, r);
    prev = r;
  }
  return seen;
}

const r5 = (v) => Math.round(v * 1e5) / 1e5;

// Turns new GPS rows into upload chunks: [{ ride, t0, km, cells, pts: [lat, lng, t, ...] }].
// - Points inside privacy zones are dropped, and the trail is split there.
// - Points are thinned to about 10 m apart; km and new ground use every point.
// - `prev` is the last uploaded row (so a ride continues smoothly across uploads).
export function buildChunks(rows, prev, seen, zones) {
  const chunks = [];
  let cur = null, lastKept = null, lastRow = prev && !inZone(zones, prev) ? prev : null;
  const start = (r) => {
    cur = { ride: r.ride, t0: r.t, km: 0, cells: 0, pts: [] };
    chunks.push(cur);
    lastKept = null;
    if (lastRow && joined(lastRow, r)) {            // repeat the joining point so there's no gap
      cur.pts.push(r5(lastRow.lat), r5(lastRow.lng), lastRow.t);
      lastKept = lastRow;
    }
  };
  for (const r of rows) {
    if (inZone(zones, r)) { cur = null; lastRow = null; continue; }
    if (!cur || cur.ride !== r.ride || cur.pts.length >= 4500) start(r);
    if (lastRow && joined(lastRow, r)) cur.km += dist(lastRow, r) / 1000;
    cur.cells += addCells(seen, lastRow, r);
    if (!lastKept || dist(lastKept, r) >= 10 || r.t - lastKept.t >= MAX_GAP_MS) {
      cur.pts.push(r5(r.lat), r5(r.lng), r.t);
      lastKept = r;
    }
    lastRow = r;
  }
  for (const c of chunks) c.km = Math.round(c.km * 1000) / 1000;
  return chunks.filter((c) => c.pts.length >= 3);
}
