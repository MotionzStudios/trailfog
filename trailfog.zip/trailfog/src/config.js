// Server and map details. The GitHub build fills these in from the repository
// secrets SUPABASE_URL, SUPABASE_KEY and MAPTILER_KEY. Leave as they are here.
export const SUPABASE_URL = 'PASTE_SUPABASE_URL';
export const SUPABASE_KEY = 'PASTE_SUPABASE_KEY';
export const MAPTILER_KEY = 'PASTE_MAPTILER_KEY';
