// Full-screen viewer for the photos pinned at one spot. Swipe left/right between them.
// Your own photos can be deleted; your group's photos show who took them.
import React, { useEffect, useState } from 'react';
import { FlatList, Image, Modal, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

const pad = (n) => (n < 10 ? '0' : '') + n;
function when(t) {
  const d = new Date(t);
  return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear() + '  ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
}

export default function PhotoViewer({ list, top, bottom, onClose, onDelete }) {
  const { width, height } = useWindowDimensions();
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (index > list.length - 1) setIndex(Math.max(0, list.length - 1));
  }, [list.length, index]);

  const photo = list[Math.min(index, list.length - 1)];
  if (!photo) return null;

  return (
    <Modal visible animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={s.root}>
        <FlatList
          data={list}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          keyExtractor={(p) => String(p.id)}
          getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
          onMomentumScrollEnd={(e) => setIndex(Math.round(e.nativeEvent.contentOffset.x / width))}
          renderItem={({ item }) => (
            item.uri
              ? <Image source={{ uri: item.uri }} style={{ width, height }} resizeMode="contain" />
              : <View style={{ width, height, alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={s.missing}>{item.error || 'Photo could not be loaded'}</Text>
                </View>
          )}
        />

        <View style={[s.bar, { top: top + 8 }]}>
          <View style={{ flex: 1 }}>
            <Text style={s.when}>{photo.owner ? photo.owner + '  ·  ' : ''}{when(photo.t)}</Text>
            <Text style={s.where}>{photo.lat.toFixed(5)}, {photo.lng.toFixed(5)}</Text>
          </View>
          {list.length > 1 ? <Text style={s.count}>{index + 1} of {list.length}</Text> : null}
        </View>

        <View style={[s.actions, { bottom: bottom + 20 }]}>
          {photo.mine ? (
            <Pressable style={[s.btn, s.del]} onPress={() => onDelete(photo)}>
              <Text style={[s.btnText, { color: '#FF8A80' }]}>Delete</Text>
            </Pressable>
          ) : null}
          <Pressable style={[s.btn, s.close]} onPress={onClose}>
            <Text style={[s.btnText, { color: '#1A1F27' }]}>Close</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  bar: {
    position: 'absolute', left: 12, right: 12, flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(20,24,31,0.85)', borderRadius: 14, paddingVertical: 10, paddingHorizontal: 14,
  },
  when: { color: '#F4F6F8', fontSize: 15, fontWeight: '700' },
  where: { color: '#A7B0BC', fontSize: 12, marginTop: 2 },
  count: { color: '#F2A93B', fontSize: 14, fontWeight: '700', marginLeft: 12 },
  missing: { color: '#A7B0BC', fontSize: 15, textAlign: 'center', paddingHorizontal: 32 },
  actions: { position: 'absolute', left: 24, right: 24, flexDirection: 'row', gap: 12 },
  btn: { flex: 1, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  del: { backgroundColor: 'rgba(20,24,31,0.9)', borderWidth: 1, borderColor: 'rgba(229,72,77,0.5)' },
  close: { backgroundColor: '#F2A93B' },
  btnText: { fontSize: 16, fontWeight: '800' },
});
