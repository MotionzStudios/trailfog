// Turns web/map.html into src/mapHtml.js so the app can load it.
// Run after editing the map:  node scripts/build-map.js
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'web', 'map.html'), 'utf8');
const out =
  '// GENERATED from web/map.html by scripts/build-map.js. Edit map.html, not this file.\n' +
  'export default ' + JSON.stringify(html) + ';\n';
fs.writeFileSync(path.join(root, 'src', 'mapHtml.js'), out);
console.log('Wrote src/mapHtml.js (' + html.length + ' characters)');
