// Turns web/map.html into src/mapHtml.js so the app can load it.
// Run after editing the map:  node scripts/build-map.js
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
let html = fs.readFileSync(path.join(root, 'web', 'map.html'), 'utf8');
// Put the translations into the page (the app passes the phone's language in as window.TF_LANG).
const dir = path.join(root, 'src', 'i18n'), strings = {};
for (const f of fs.readdirSync(dir)) if (f.endsWith('.json')) strings[f.replace('.json', '')] = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
if (html.indexOf('/*TF_I18N*/') < 0) throw new Error('map.html is missing the /*TF_I18N*/ placeholder');
html = html.replace('/*TF_I18N*/', 'window.TF_STRINGS=' + JSON.stringify(strings).replace(/</g, '\\u003c') + ';');
const out =
  '// GENERATED from web/map.html by scripts/build-map.js. Edit map.html, not this file.\n' +
  'export default ' + JSON.stringify(html) + ';\n';
fs.writeFileSync(path.join(root, 'src', 'mapHtml.js'), out);
console.log('Wrote src/mapHtml.js (' + html.length + ' characters, languages: en ' + Object.keys(strings).join(' ') + ')');
