// Lists every English string that goes through L() in map.html or t() in the app code.
// Run: node scripts/i18n-keys.js   (prints JSON array; also checks each language file for gaps)
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const keys = new Set();
function literals(src, fn) {
  const re = new RegExp('(^|[^A-Za-z0-9_.$])' + fn + '\\(', 'g'); let m;
  while ((m = re.exec(src))) {
    let i = m.index + m[0].length, depth = 1, brace = 0;
    while (i < src.length && depth > 0) {
      const c = src[i];
      if (c === "'" || c === '"' || c === '`') {
        let j = i + 1, s = '';
        while (j < src.length && src[j] !== c) { if (src[j] === '\\') { s += src[j + 1]; j += 2; continue; } s += src[j]; j++; }
        if (depth === 1 && brace === 0 && c !== '`') keys.add(s);
        i = j + 1; continue;
      }
      if (c === '(') depth++; else if (c === ')') depth--; else if (c === '{') brace++; else if (c === '}') brace--;
      i++;
    }
  }
}
const html = fs.readFileSync(path.join(root, 'web/map.html'), 'utf8');
literals(html, 'L'); literals(html, 'signInHtml');
for (const m of html.matchAll(/data-i18n(?:-aria)?="([^"]+)"/g)) keys.add(m[1]);
for (const m of html.matchAll(/name: '([^']+)', desc: '([^']+)'/g)) { keys.add(m[1]); keys.add(m[2]); }
keys.add('New ground this month');
for (const f of ['App.js', 'src/PhotoViewer.js', 'src/photos.js', 'src/group.js', 'src/auth.js', 'src/tracking.js', 'src/gpx.js']) {
  const src = fs.readFileSync(path.join(root, f), 'utf8');
  literals(src, 't'); literals(src, 't\\.key');
}
// messages that arrive as errors and are shown through L(group.error)
['Type your rider name first.', 'Type the invite code you were sent.', 'You are no longer in this group.',
 'No connection to the group server. Check your signal and try again.', 'No connection. Check your signal and try again.',
 'Sign in first to use groups and leaderboards.', 'Join a group to see its leaderboard.', 'No group with that code',
 'Please sign in first', 'This rider belongs to another account', 'You are not in this group', 'You cannot block yourself',
 'You cannot report yourself', 'Photo not found', 'Photo too large', 'Rider not found', 'Google sign-in did not finish. Try again.',
 'Apple did not return a sign-in token.'].forEach((k) => keys.add(k));
for (const k of ['Sign in', 'Use groups and leaderboards, and keep your rider if you change phones.']) keys.add(k);
['all', 'ios', 'week'].forEach((k) => keys.delete(k));   // comparisons inside L(a === 'x' ? ...), not text
const list = [...keys].filter((k) => /[A-Za-z]/.test(k)).sort();
if (process.argv[2] === '--check') {
  let bad = 0;
  for (const f of fs.readdirSync(path.join(root, 'src/i18n'))) {
    const d = JSON.parse(fs.readFileSync(path.join(root, 'src/i18n', f), 'utf8'));
    const miss = list.filter((k) => !d[k]), extra = Object.keys(d).filter((k) => !keys.has(k));
    const ph = list.filter((k) => d[k] && JSON.stringify((k.match(/\{\w+\}/g) || []).sort()) !== JSON.stringify((d[k].match(/\{\w+\}/g) || []).sort()));
    console.log(f, 'missing', miss.length, 'extra', extra.length, 'placeholder mismatch', ph.length);
    if (miss.length) console.log('  missing:', miss.slice(0, 8));
    if (extra.length) console.log('  extra:', extra.slice(0, 8));
    if (ph.length) console.log('  placeholders:', ph);
    bad += miss.length + ph.length;
  }
  process.exit(bad ? 1 : 0);
} else console.log(JSON.stringify(list, null, 1));
