#!/usr/bin/env bash
# TrailFog -> TestFlight, run from a GitHub Codespace (no Mac needed).
# Usage, from the repo folder:   bash trailfog/scripts/ios-testflight.sh
set -e
cd "$(dirname "$0")/../.."
ROOT="$PWD"

# Node 22 (Codespaces has nvm)
if [ -s "$NVM_DIR/nvm.sh" ]; then . "$NVM_DIR/nvm.sh"; nvm install 22 >/dev/null; nvm use 22 >/dev/null; fi
echo "Node $(node -v)"

unzip -oq trailfog.zip

# Keep the Expo project ID from an earlier run
OLD_ID=""
if [ -f app/app.json ]; then
  OLD_ID=$(node -e "try{console.log(require('./app/app.json').expo.extra.eas.projectId||'')}catch(e){}")
fi

if [ ! -d app ]; then
  npx --yes create-expo-app@latest app --template blank --no-install
fi
cp -r trailfog/src trailfog/web trailfog/scripts app/
mkdir -p app/assets && cp -r trailfog/assets/. app/assets/
cp trailfog/App.js trailfog/index.js trailfog/app.json trailfog/eas.json app/
cd app
node scripts/build-map.js
node -e "
const fs=require('fs');
const p=JSON.parse(fs.readFileSync('package.json'));p.name='trailfog';p.main='index.js';
fs.writeFileSync('package.json',JSON.stringify(p,null,2));
const id=process.argv[1];
if(id){const a=JSON.parse(fs.readFileSync('app.json'));a.expo.extra={...(a.expo.extra||{}),eas:{projectId:id}};fs.writeFileSync('app.json',JSON.stringify(a,null,2));}
" "$OLD_ID"

# Group server (publishable key only - never the secret key)
SB_URL="${SUPABASE_URL:-}"; SB_KEY="${SUPABASE_KEY:-}"
if [ -z "$SB_URL" ]; then read -rp "Supabase project URL: " SB_URL; fi
if [ -z "$SB_KEY" ]; then read -rp "Supabase PUBLISHABLE key (sb_publishable_...): " SB_KEY; fi
SB_URL="$SB_URL" SB_KEY="$SB_KEY" node -e "
const fs=require('fs');const url=process.env.SB_URL.trim().replace(/\/+$/,'');const key=process.env.SB_KEY.trim();
if(key.startsWith('sb_secret')){console.error('That is the SECRET key - use the publishable one.');process.exit(1)}
let s=fs.readFileSync('src/config.js','utf8');s=s.replace('PASTE_SUPABASE_URL',url).replace('PASTE_SUPABASE_KEY',key);fs.writeFileSync('src/config.js',s);"

# Map key (MapTiler)
MT_KEY="${MAPTILER_KEY:-}"
if [ -z "$MT_KEY" ]; then read -rp "MapTiler API key: " MT_KEY; fi
MT_KEY="$MT_KEY" node -e "
const fs=require('fs');let s=fs.readFileSync('src/config.js','utf8');s=s.replace('PASTE_MAPTILER_KEY',process.env.MT_KEY.trim());fs.writeFileSync('src/config.js',s);"

npm install
bash scripts/deps.sh

# Build in Expo's cloud Macs, then send straight to TestFlight
export EAS_NO_VCS=1
npx --yes eas-cli@latest build --platform ios --profile production --auto-submit
