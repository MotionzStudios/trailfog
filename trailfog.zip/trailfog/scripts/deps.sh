#!/usr/bin/env bash
# Installs TrailFog's native modules into the Expo project (run inside the app folder).
set -e
npx expo install expo-location expo-task-manager expo-sqlite react-native-webview expo-image-picker \
  expo-file-system expo-image-manipulator expo-document-picker expo-splash-screen \
  expo-apple-authentication expo-web-browser expo-crypto expo-linking expo-constants expo-intent-launcher expo-localization
