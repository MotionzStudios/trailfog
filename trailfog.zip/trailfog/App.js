import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, AppState, Linking, Share, StatusBar, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import * as Location from 'expo-location';

import MAP_HTML from './src/mapHtml';
import PhotoViewer from './src/PhotoViewer';
import { takePhoto, removePhoto } from './src/photos';
import { importGpxFiles } from './src/gpx';
import * as DB from './src/db';
import * as Group from './src/group';
import * as Offline from './src/offline';
import {
  getCurrentRideId, isRiding, requestPermissions, resetLastPoint,
  startRide, stopRide, subscribe,
} from './src/tracking';

// The app draws behind the phone's status bar (top) and navigation buttons (bottom),
// so the map screen keeps its buttons this far in from those edges.
const TOP = Math.round(StatusBar.currentHeight || 24);
const BOTTOM = 48;
const BEFORE_LOAD =
  "document.documentElement.style.setProperty('--top','" + TOP + "px');" +
  "document.documentElement.style.setProperty('--bottom','" + BOTTOM + "px');true;";
const CHUNK = 4000;
const GROUP_POLL_MS = 60 * 1000;

// Sends errors from async code to the on-screen error report (see src/Boot.js).
function showError(e) {
  const h = global.ErrorUtils && global.ErrorUtils.getGlobalHandler();
  if (h) h(e, false); else console.error(e);
}

function flatten(rows) {
  const flat = [];
  for (const r of rows) flat.push(Math.round(r.lat * 1e6) / 1e6, Math.round(r.lng * 1e6) / 1e6, r.t, r.ride);
  return flat;
}

export default function App() {
  const web = useRef(null);
  const ready = useRef(false);
  const watch = useRef(null);
  const watchStarting = useRef(false);
  const photos = useRef([]);
  const groupPhotos = useRef([]);
  const groupMembers = useRef([]);
  const photoCache = useRef(new Map());
  const pulling = useRef(false);
  const [viewer, setViewer] = useState(null);

  // ---------- App -> map ----------
  const send = useCallback((msg) => {
    if (!ready.current || !web.current) return;
    web.current.injectJavaScript('window.TF&&window.TF.receive(' + JSON.stringify(msg) + ');true;');
  }, []);
  const toast = useCallback((text) => send({ type: 'toast', text }), [send]);

  const sendPhotos = useCallback(async () => {
    photos.current = await DB.loadPhotos();
    send({ type: 'photos', list: photos.current.map((p) => ({ id: p.id, lat: p.lat, lng: p.lng, t: p.t })) });
  }, [send]);

  const sendState = useCallback(async () => {
    send({
      type: 'state',
      riding: await isRiding(),
      rideId: await getCurrentRideId(),
      reveal: Number(await DB.getMeta('revealM')) || 40,
      unlocked: await DB.getJson('unlocked', []),
      rideNames: await DB.getJson('rideNames', {}),
    });
  }, [send]);

  const sendOffline = useCallback(async (progress) => {
    send({ type: 'offline', areas: await Offline.areas(), progress: progress || null, maxTiles: Offline.MAX_TILES });
  }, [send]);

  // ---------- group ----------
  const sendGroupInfo = useCallback(async (extra) => {
    const me = Group.configured() ? await Group.me() : { id: null, name: '' };
    const info = await Group.current();
    const members = (await DB.getJson('groupMembers', [])).map((m) => ({ ...m, me: m.id === me.id }));
    groupMembers.current = members;
    send({ type: 'group', configured: Group.configured(), name: me.name, info, members, ...(extra || {}) });
  }, [send]);

  const sendGroupData = useCallback(async () => {
    const me = Group.configured() ? await Group.me() : { id: null };
    send({ type: 'groupReset' });
    if (!(await Group.current())) return;
    const chunks = await DB.loadRemoteChunks();
    for (let i = 0; i < chunks.length; i += 40) {
      send({ type: 'groupTracks', chunks: chunks.slice(i, i + 40).filter((c) => c.rider !== me.id) });
    }
    send({ type: 'groupPhotos', list: groupPhotos.current.map((p) => ({ id: 'g:' + p.id, rider: p.rider, lat: p.lat, lng: p.lng, t: p.t })) });
  }, [send]);

  const groupSync = useCallback(async (opts) => {
    if (!Group.configured() || !(await Group.current()) || pulling.current) return;
    pulling.current = true;
    try {
      if (opts && opts.push) await Group.push();
      const res = await Group.pull();
      if (res) {
        groupPhotos.current = res.photos;
        if (res.changed || (opts && opts.force)) {
          await sendGroupInfo();
          await sendGroupData();
        }
      }
    } catch (e) {
      if (opts && opts.loud) send({ type: 'group', error: String(e.message || e) });
      if (/not in this group/i.test(String(e.message))) {
        await Group.leave().catch(() => {});
        await sendGroupInfo({ error: 'You are no longer in this group.' });
        await sendGroupData();
      }
    } finally {
      pulling.current = false;
    }
  }, [send, sendGroupInfo, sendGroupData]);

  // ---------- full refresh of the map ----------
  const sync = useCallback(async () => {
    await sendPhotos();
    const rows = await DB.loadPoints();
    send({ type: 'reset' });
    await sendState();
    for (let i = 0; i < rows.length; i += CHUNK) {
      send({ type: 'points', pts: flatten(rows.slice(i, i + CHUNK)) });
    }
    await sendOffline();
    await sendGroupInfo();
    await sendGroupData();
    send({ type: 'synced' });
  }, [send, sendPhotos, sendState, sendOffline, sendGroupInfo, sendGroupData]);

  // ---------- live position ----------
  const sendPosition = useCallback((loc, center) => {
    send({
      type: 'me', lat: loc.coords.latitude, lng: loc.coords.longitude,
      acc: loc.coords.accuracy || 0, heading: loc.coords.heading, center: !!center,
    });
  }, [send]);

  const startWatch = useCallback(async (center) => {
    const fg = await Location.getForegroundPermissionsAsync();
    if (fg.status !== 'granted') return;
    const last = await Location.getLastKnownPositionAsync();
    if (last) sendPosition(last, center);
    if (watch.current || watchStarting.current) return;
    watchStarting.current = true;
    try {
      watch.current = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, distanceInterval: 3, timeInterval: 2000 },
        (loc) => sendPosition(loc, false)
      );
    } finally {
      watchStarting.current = false;
    }
  }, [sendPosition]);

  const stopWatch = useCallback(() => {
    if (watch.current) { watch.current.remove(); watch.current = null; }
  }, []);

  // ---------- riding ----------
  const toggleRide = useCallback(async () => {
    if (await isRiding()) {
      await stopRide();
      await sendState();
      groupSync({ push: true }).catch(() => {});
      return;
    }
    const perm = await requestPermissions();
    if (perm === 'denied') {
      Alert.alert('Location needed', 'TrailFog needs your location to clear the fog.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    const begin = async () => {
      try {
        await startRide();
        await sendState();
        await startWatch(true);
      } catch (e) {
        Alert.alert('Could not start tracking', String((e && e.message) || e));
      }
    };
    if (perm === 'no-background') {
      Alert.alert(
        'Allow location "All the time"',
        'To keep mapping with your phone locked, open Settings > Permissions > Location and choose "Allow all the time".',
        [
          { text: 'Ride anyway', onPress: () => { begin(); } },
          { text: 'Open settings', onPress: () => Linking.openSettings() },
        ]
      );
      return;
    }
    await begin();
  }, [sendState, startWatch, groupSync]);

  const locate = useCallback(async () => {
    const r = await Location.requestForegroundPermissionsAsync();
    if (r.status !== 'granted') {
      Alert.alert('Location needed', 'Allow location to see where you are on the map.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    await startWatch(true);
    try {
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      sendPosition(pos, true);
    } catch {
      Alert.alert('Location unavailable', 'Turn on location (GPS) on your phone and try again.');
    }
  }, [startWatch, sendPosition]);

  // ---------- photos ----------
  const photo = useCallback(async () => {
    const id = await takePhoto();
    if (id == null) return;
    await sendPhotos();
    send({ type: 'photoAdded', id });
    groupSync({ push: true }).catch(() => {});
  }, [send, sendPhotos, groupSync]);

  const openPhotos = useCallback(async (ids) => {
    const list = [];
    const remoteIds = ids.filter((id) => typeof id === 'string' && id.startsWith('g:'));
    if (remoteIds.length) toast(remoteIds.length > 1 ? 'Loading photos…' : 'Loading photo…');
    for (const id of ids) {
      if (typeof id === 'string' && id.startsWith('g:')) {
        const gid = Number(id.slice(2));
        const p = groupPhotos.current.find((x) => x.id === gid);
        if (!p) continue;
        const owner = (groupMembers.current.find((m) => m.id === p.rider) || {}).name || 'Rider';
        let uri = photoCache.current.get(gid), error = null;
        if (!uri) {
          try {
            uri = 'data:image/jpeg;base64,' + (await Group.getPhoto(gid));
            photoCache.current.set(gid, uri);
          } catch (e) { error = String(e.message || e); }
        }
        list.push({ id, lat: p.lat, lng: p.lng, t: p.t, uri, error, owner, mine: false });
      } else {
        const p = photos.current.find((x) => x.id === id);
        if (p) list.push({ ...p, mine: true });
      }
    }
    if (list.length) setViewer(list);
  }, [toast]);

  const askDelete = useCallback((p) => {
    Alert.alert('Delete this photo?', 'It will be removed from TrailFog (and from your group). This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive',
        onPress: () => {
          (async () => {
            await removePhoto(p);
            await sendPhotos();
            setViewer((v) => {
              const rest = v ? v.filter((x) => x.id !== p.id) : [];
              return rest.length ? rest : null;
            });
            groupSync({ push: true }).catch(() => {});
          })().catch(showError);
        },
      },
    ]);
  }, [sendPhotos, groupSync]);

  // ---------- rides ----------
  const deleteRide = useCallback(async (id) => {
    await DB.deleteRide(id);
    const names = await DB.getJson('rideNames', {});
    delete names[id];
    await DB.setJson('rideNames', names);
    try { await Group.deleteRide(id); } catch {}
    await sync();
    toast('Ride deleted');
  }, [sync, toast]);

  const importGpx = useCallback(async () => {
    const r = await importGpxFiles();
    if (!r) return;
    await sync();
    const parts = [];
    if (r.rides) parts.push('Imported ' + r.rides + (r.rides === 1 ? ' ride' : ' rides'));
    if (r.duplicates.length) parts.push(r.duplicates.length + ' already imported');
    if (r.skipped.length) parts.push(r.skipped.length + " couldn't be read (not GPX?)");
    toast(parts.join(' · ') || 'Nothing imported');
    if (r.rides) groupSync({ push: true }).catch(() => {});
  }, [sync, toast, groupSync]);

  // ---------- group actions ----------
  const groupAction = useCallback(async (fn, okText) => {
    send({ type: 'group', busy: true, error: null });
    try {
      await fn();
      await sendGroupInfo({ busy: false, error: null });
      if (okText) toast(okText);
      await groupSync({ push: true, force: true, loud: true });
    } catch (e) {
      await sendGroupInfo({ busy: false, error: String(e.message || e) });
    }
  }, [send, sendGroupInfo, groupSync, toast]);

  // ---------- offline maps ----------
  const downloadArea = useCallback(async (req) => {
    try {
      await sendOffline({ done: 0, total: 1, failed: 0, bytes: 0 });
      const r = await Offline.downloadArea(req, (p) => { sendOffline(p).catch(() => {}); });
      await sendOffline();
      if (r.cancelled) toast('Download cancelled');
      else toast(r.failed ? 'Saved, but ' + r.failed + ' map pieces failed' : 'Area saved for offline use');
    } catch (e) {
      await sendOffline();
      toast(String(e.message || e));
    }
  }, [sendOffline, toast]);

  // ---------- map -> app ----------
  const onMessage = useCallback((e) => {
    let m;
    try { m = JSON.parse(e.nativeEvent.data); } catch { return; }
    (async () => {
      switch (m.type) {
        case 'ready':
          ready.current = true;
          await sync();
          await startWatch(true);
          groupSync({ push: true }).catch(() => {});
          break;
        case 'ride': await toggleRide(); break;
        case 'locate': await locate(); break;
        case 'reveal': await DB.setMeta('revealM', m.m); break;
        case 'photo': await photo(); break;
        case 'openPhotos': await openPhotos(m.ids || []); break;
        case 'reset':
          await DB.clearPoints();
          resetLastPoint();
          try { await Group.deleteAllMine(); } catch {}
          await sync();
          break;
        case 'unlock': {
          const have = new Set(await DB.getJson('unlocked', []));
          (m.ids || []).forEach((id) => have.add(id));
          await DB.setJson('unlocked', [...have]);
          break;
        }
        case 'deleteRide': await deleteRide(m.id); break;
        case 'importGpx': await importGpx(); break;
        case 'groupCreate': await groupAction(() => Group.create(m.name, m.groupName), 'Group created'); break;
        case 'groupJoin': await groupAction(() => Group.join(m.name, m.code), 'Joined the group'); break;
        case 'groupLeave':
          await groupAction(() => Group.leave(), 'You left the group');
          await sendGroupData();
          break;
        case 'groupSetName': await groupAction(() => Group.setName(m.name), 'Name saved'); break;
        case 'groupRefresh': await groupSync({ push: true, force: true, loud: true }); toast('Group updated'); break;
        case 'groupShare': {
          const g = await Group.current();
          if (g) {
            await Share.share({
              message: 'Ride with me on TrailFog! Open TrailFog > menu > Group > Join, and enter the code ' + g.code + ' (group "' + g.name + '").',
            });
          }
          break;
        }
        case 'downloadArea': await downloadArea(m); break;
        case 'cancelDownload': Offline.cancel(); break;
        case 'deleteArea': await Offline.deleteArea(m.id); await sendOffline(); toast('Offline area deleted'); break;
        case 'tile': send({ type: 'tileData', key: m.key, data: await Offline.readTile(m.key) }); break;
        case 'error': showError(new Error('Map page: ' + m.message + '\n' + (m.stack || ''))); break;
        default: break;
      }
    })().catch(showError);
  }, [sync, startWatch, toggleRide, locate, photo, openPhotos, deleteRide, importGpx, groupAction,
    groupSync, sendGroupData, downloadArea, sendOffline, send, toast]);

  // New GPS points from the background tracker
  useEffect(() => subscribe((fresh) => send({ type: 'points', pts: flatten(fresh) })), [send]);

  // Refresh when coming back to the app; stop the live dot when leaving
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') {
        sync().then(() => startWatch(false)).then(() => groupSync({ push: true })).catch(showError);
      } else {
        stopWatch();
      }
    });
    return () => { sub.remove(); stopWatch(); };
  }, [sync, startWatch, stopWatch, groupSync]);

  // Check the group for new trails every minute while the app is open
  useEffect(() => {
    let n = 0;
    const timer = setInterval(() => {
      if (AppState.currentState !== 'active') return;
      n++;
      groupSync({ push: n % 3 === 0 }).catch(() => {});
    }, GROUP_POLL_MS);
    return () => clearInterval(timer);
  }, [groupSync]);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <WebView
        ref={web}
        style={styles.root}
        source={{ html: MAP_HTML, baseUrl: 'https://trailfog.app/' }}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        injectedJavaScriptBeforeContentLoaded={BEFORE_LOAD}
        onMessage={onMessage}
        overScrollMode="never"
        setBuiltInZoomControls={false}
        onRenderProcessGone={() => { ready.current = false; if (web.current) web.current.reload(); }}
        onContentProcessDidTerminate={() => { ready.current = false; if (web.current) web.current.reload(); }}
      />
      {viewer ? (
        <PhotoViewer list={viewer} top={TOP} bottom={BOTTOM} onClose={() => setViewer(null)} onDelete={askDelete} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1F27' },
});
