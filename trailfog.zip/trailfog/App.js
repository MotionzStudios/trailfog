import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, AppState, Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import MapView from 'react-native-maps';
import * as Location from 'expo-location';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';

import FogOverlay from './src/FogOverlay';
import { clearPoints, getMeta, loadPoints, setMeta } from './src/db';
import {
  getCurrentRideId, isRiding, requestPermissions, resetLastPoint,
  startRide, stopRide, subscribe,
} from './src/tracking';
import { addCells, cellsToKm2, enrichSeq } from './src/geo';

const REVEAL_OPTIONS = [
  { label: 'Narrow (25 m)', m: 25 },
  { label: 'Normal (40 m)', m: 40 },
  { label: 'Wide (75 m)', m: 75 },
];
const WORLD = { latitude: 30, longitude: 0, latitudeDelta: 100, longitudeDelta: 100 };
const BASE_MAP = Platform.OS === 'android' ? 'terrain' : 'standard';
const ACCENT = '#F2A93B';

// Sends errors from async code to the on-screen error report (see src/Boot.js).
function showError(e) {
  const h = global.ErrorUtils && global.ErrorUtils.getGlobalHandler();
  if (h) h(e, false); else console.error(e);
}

export default function App({ noMap = false }) {
  return (
    <SafeAreaProvider>
      <TrailFog noMap={noMap} />
    </SafeAreaProvider>
  );
}

function TrailFog({ noMap }) {
  const insets = useSafeAreaInsets();
  const mapRef = useRef(null);

  const [points, setPoints] = useState([]);
  const [region, setRegion] = useState(WORLD);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [riding, setRiding] = useState(false);
  const [rideId, setRideId] = useState(null);
  const [follow, setFollow] = useState(true);
  const [mapType, setMapType] = useState(BASE_MAP);
  const [revealM, setRevealM] = useState(40);
  const [cellCount, setCellCount] = useState(0);

  const followRef = useRef(follow);
  followRef.current = follow;
  const cellsRef = useRef(new Set());
  const processedRef = useRef(0);

  // ---------- loading ----------
  const reload = useCallback(async () => {
    const rows = await loadPoints();
    cellsRef.current = new Set();
    processedRef.current = 0;
    setPoints(enrichSeq(rows, null));
    setRiding(await isRiding());
    setRideId(await getCurrentRideId());
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const saved = await getMeta('revealM');
        if (saved) setRevealM(Number(saved));
        await reload();
        const fg = await Location.getForegroundPermissionsAsync();
        if (fg.status === 'granted') {
          const pos = await Location.getLastKnownPositionAsync();
          if (pos) jumpTo(pos.coords.latitude, pos.coords.longitude, 0.02);
        }
      } catch (e) {
        showError(e);
      }
    })();
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') reload().catch(showError); });
    return () => sub.remove();
  }, [reload]);

  // New GPS points while the app is open
  useEffect(() => subscribe((fresh) => {
    setPoints((prev) => prev.concat(enrichSeq(fresh, prev[prev.length - 1] || null)));
    if (followRef.current && mapRef.current) {
      const last = fresh[fresh.length - 1];
      mapRef.current.animateCamera({ center: { latitude: last.lat, longitude: last.lng } }, { duration: 600 });
    }
  }), []);

  // Explored-area counter, updated incrementally
  useEffect(() => {
    const from = processedRef.current;
    addCells(cellsRef.current, points.slice(from), points[from - 1] || null);
    processedRef.current = points.length;
    setCellCount(cellsRef.current.size);
  }, [points]);

  const rideKm = useMemo(() => {
    if (rideId == null) return 0;
    let m = 0;
    for (const p of points) if (p.ride === rideId) m += p.d;
    return m / 1000;
  }, [points, rideId]);

  // ---------- actions ----------
  function jumpTo(latitude, longitude, delta = 0.01) {
    mapRef.current?.animateToRegion({ latitude, longitude, latitudeDelta: delta, longitudeDelta: delta }, 700);
  }

  async function centerOnMe() {
    setFollow(true);
    try {
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      jumpTo(pos.coords.latitude, pos.coords.longitude, Math.min(region.longitudeDelta, 0.02));
    } catch {
      Alert.alert('Location unavailable', 'Turn on location services to find yourself on the map.');
    }
  }

  function toggleRide() {
    toggleRideInner().catch(showError);
  }

  async function toggleRideInner() {
    if (riding) {
      await stopRide();
      setRiding(false);
      return;
    }
    const perm = await requestPermissions();
    if (perm === 'denied') {
      Alert.alert('Location needed', 'TrailFog needs your location to clear the fog.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    if (perm === 'no-background') {
      Alert.alert(
        'Allow location "All the time"',
        Platform.OS === 'ios'
          ? 'To keep mapping with your phone locked, set Location to "Always" in Settings > TrailFog.'
          : 'To keep mapping with your phone locked, set Location to "Allow all the time" in the app settings.',
        [
          { text: 'Ride anyway', onPress: () => beginRide() },
          { text: 'Open settings', onPress: () => Linking.openSettings() },
        ]
      );
      return;
    }
    beginRide();
  }

  async function beginRide() {
    try {
      const id = await startRide();
      setRideId(id);
      setRiding(true);
      setFollow(true);
      centerOnMe();
    } catch (e) {
      Alert.alert('Could not start tracking', String(e?.message || e));
    }
  }

  function openMenu() {
    Alert.alert('TrailFog', undefined, [
      { text: 'Fog clearing width', onPress: pickReveal },
      { text: 'Reset all fog', style: 'destructive', onPress: confirmReset },
      { text: 'Cancel', style: 'cancel' },
    ]);
  }

  function pickReveal() {
    Alert.alert('How wide should the fog clear?', `Currently ${revealM} m either side`,
      REVEAL_OPTIONS.map((o) => ({
        text: o.label,
        onPress: () => { setRevealM(o.m); setMeta('revealM', o.m); },
      })));
  }

  function confirmReset() {
    Alert.alert('Reset all fog?', 'Every trail you have ridden will be covered again. This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reset', style: 'destructive',
        onPress: async () => {
          await clearPoints();
          resetLastPoint();
          await reload();
        },
      },
    ]);
  }

  // ---------- UI ----------
  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={StyleSheet.absoluteFill}
        onLayout={(e) => setSize({ width: e.nativeEvent.layout.width, height: e.nativeEvent.layout.height })}>
        {noMap ? null : <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          initialRegion={WORLD}
          mapType={mapType}
          showsUserLocation
          showsMyLocationButton={false}
          showsCompass={false}
          toolbarEnabled={false}
          rotateEnabled={false}
          pitchEnabled={false}
          onRegionChange={setRegion}
          onRegionChangeComplete={setRegion}
          onPanDrag={() => follow && setFollow(false)}
        />}
        <FogOverlay points={points} region={region} width={size.width} height={size.height} revealM={revealM} />
      </View>

      {/* Top stats */}
      <View style={[styles.topCard, { top: insets.top + 10 }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>TRAILFOG</Text>
          <View style={styles.statusRow}>
            <View style={[styles.dot, { backgroundColor: riding ? '#E5484D' : '#5B6472' }]} />
            <Text style={styles.status}>{riding ? 'Recording ride' : 'Not recording'}</Text>
          </View>
        </View>
        <Stat value={cellsToKm2(cellCount).toFixed(2)} unit="km²" label="uncovered" />
        <Stat value={rideKm.toFixed(1)} unit="km" label={riding ? 'this ride' : 'last ride'} />
      </View>

      {/* Side buttons */}
      <View style={[styles.side, { top: insets.top + 100 }]}>
        <RoundButton icon={follow ? 'navigate' : 'navigate-outline'} active={follow} onPress={centerOnMe} />
        <RoundButton icon="layers-outline"
          onPress={() => setMapType((t) => (t === 'hybrid' ? BASE_MAP : 'hybrid'))} />
        <RoundButton icon="ellipsis-horizontal" onPress={openMenu} />
      </View>

      {/* Ride button */}
      <View style={[styles.bottom, { bottom: insets.bottom + 20 }]}>
        <Pressable onPress={toggleRide}
          style={({ pressed }) => [styles.rideBtn, riding && styles.rideBtnStop, pressed && { opacity: 0.85 }]}>
          <Ionicons name={riding ? 'stop' : 'play'} size={22} color={riding ? '#fff' : '#1A1F27'} />
          <Text style={[styles.rideText, riding && { color: '#fff' }]}>{riding ? 'Stop ride' : 'Start ride'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function Stat({ value, unit, label }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statValue}>{value}<Text style={styles.statUnit}> {unit}</Text></Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function RoundButton({ icon, onPress, active }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.round, pressed && { opacity: 0.7 }]}>
      <Ionicons name={icon} size={22} color={active ? ACCENT : '#E8ECF1'} />
    </Pressable>
  );
}

const card = {
  backgroundColor: 'rgba(20,24,31,0.92)',
  borderColor: 'rgba(255,255,255,0.08)',
  borderWidth: 1,
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1F27' },
  topCard: {
    ...card, position: 'absolute', left: 12, right: 12, borderRadius: 18,
    paddingVertical: 12, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center',
  },
  brand: { color: ACCENT, fontWeight: '800', letterSpacing: 2, fontSize: 14 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  status: { color: '#A7B0BC', fontSize: 12 },
  stat: { alignItems: 'flex-end', marginLeft: 18 },
  statValue: { color: '#F4F6F8', fontSize: 20, fontWeight: '700', fontVariant: ['tabular-nums'] },
  statUnit: { color: '#A7B0BC', fontSize: 12, fontWeight: '500' },
  statLabel: { color: '#7D8794', fontSize: 11, marginTop: 1 },
  side: { position: 'absolute', right: 12, gap: 10 },
  round: { ...card, width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  bottom: { position: 'absolute', left: 24, right: 24, alignItems: 'center' },
  rideBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: ACCENT, height: 60, borderRadius: 30, alignSelf: 'stretch',
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 8,
  },
  rideBtnStop: { backgroundColor: '#E5484D' },
  rideText: { color: '#1A1F27', fontSize: 18, fontWeight: '800', letterSpacing: 0.5 },
});
