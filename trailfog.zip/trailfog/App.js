import React, { useCallback, useEffect, useRef } from 'react';
import { Alert, AppState, Linking, StatusBar, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import * as Location from 'expo-location';

import MAP_HTML from './src/mapHtml';
import { clearPoints, getMeta, loadPoints, setMeta } from './src/db';
import {
  getCurrentRideId, isRiding, requestPermissions, resetLastPoint,
  startRide, stopRide, subscribe,
} from './src/tracking';

const TOP = Math.round(StatusBar.currentHeight || 24);
const BEFORE_LOAD = "document.documentElement.style.setProperty('--top','" + TOP + "px');true;";
const CHUNK = 4000;

// Sends errors from async code to the on-screen error report (see src/Boot.js).
function showError(e) {
  const h = global.ErrorUtils && global.ErrorUtils.getGlobalHandler();
  if (h) h(e, false); else console.error(e);
}

function flatten(rows) {
  const flat = [];
  for (const r of rows) flat.push(Math.round(r.lat * 1e6) / 1e6, Math.round(r.lng * 1e6) / 1e6, r.t, r.ride);
  return flat;
}

export default function App() {
  const web = useRef(null);
  const ready = useRef(false);
  const watch = useRef(null);
  const watchStarting = useRef(false);

  // App -> map
  const send = useCallback((msg) => {
    if (!ready.current || !web.current) return;
    web.current.injectJavaScript('window.TF&&window.TF.receive(' + JSON.stringify(msg) + ');true;');
  }, []);

  // Push everything saved on the phone to the map
  const sync = useCallback(async () => {
    const rows = await loadPoints();
    const riding = await isRiding();
    const rideId = await getCurrentRideId();
    const reveal = Number(await getMeta('revealM')) || 40;
    send({ type: 'reset' });
    send({ type: 'state', riding, rideId, reveal });
    for (let i = 0; i < rows.length; i += CHUNK) {
      send({ type: 'points', pts: flatten(rows.slice(i, i + CHUNK)) });
    }
  }, [send]);

  const sendPosition = useCallback((loc, center) => {
    send({
      type: 'me',
      lat: loc.coords.latitude,
      lng: loc.coords.longitude,
      acc: loc.coords.accuracy || 0,
      heading: loc.coords.heading,
      center: !!center,
    });
  }, [send]);

  // Live blue-dot position while the app is on screen
  const startWatch = useCallback(async (center) => {
    const fg = await Location.getForegroundPermissionsAsync();
    if (fg.status !== 'granted') return;
    const last = await Location.getLastKnownPositionAsync();
    if (last) sendPosition(last, center);
    if (watch.current || watchStarting.current) return;
    watchStarting.current = true;
    try {
      watch.current = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, distanceInterval: 3, timeInterval: 2000 },
        (loc) => sendPosition(loc, false)
      );
    } finally {
      watchStarting.current = false;
    }
  }, [sendPosition]);

  const stopWatch = useCallback(() => {
    if (watch.current) { watch.current.remove(); watch.current = null; }
  }, []);

  const sendState = useCallback(async () => {
    send({ type: 'state', riding: await isRiding(), rideId: await getCurrentRideId(), reveal: Number(await getMeta('revealM')) || 40 });
  }, [send]);

  const toggleRide = useCallback(async () => {
    if (await isRiding()) {
      await stopRide();
      await sendState();
      return;
    }
    const perm = await requestPermissions();
    if (perm === 'denied') {
      Alert.alert('Location needed', 'TrailFog needs your location to clear the fog.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    const begin = async () => {
      try {
        await startRide();
        await sendState();
        await startWatch(true);
      } catch (e) {
        Alert.alert('Could not start tracking', String((e && e.message) || e));
      }
    };
    if (perm === 'no-background') {
      Alert.alert(
        'Allow location "All the time"',
        'To keep mapping with your phone locked, open Settings > Permissions > Location and choose "Allow all the time".',
        [
          { text: 'Ride anyway', onPress: () => { begin(); } },
          { text: 'Open settings', onPress: () => Linking.openSettings() },
        ]
      );
      return;
    }
    await begin();
  }, [sendState, startWatch]);

  const locate = useCallback(async () => {
    const r = await Location.requestForegroundPermissionsAsync();
    if (r.status !== 'granted') {
      Alert.alert('Location needed', 'Allow location to see where you are on the map.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    await startWatch(true);
    try {
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      sendPosition(pos, true);
    } catch {
      Alert.alert('Location unavailable', 'Turn on location (GPS) on your phone and try again.');
    }
  }, [startWatch, sendPosition]);

  // Map -> app
  const onMessage = useCallback((e) => {
    let m;
    try { m = JSON.parse(e.nativeEvent.data); } catch { return; }
    (async () => {
      switch (m.type) {
        case 'ready':
          ready.current = true;
          await sync();
          await startWatch(true);
          break;
        case 'ride': await toggleRide(); break;
        case 'locate': await locate(); break;
        case 'reveal': await setMeta('revealM', m.m); break;
        case 'reset':
          await clearPoints();
          resetLastPoint();
          await sync();
          break;
        case 'error': showError(new Error('Map page: ' + m.message + '\n' + (m.stack || ''))); break;
        default: break;
      }
    })().catch(showError);
  }, [sync, startWatch, toggleRide, locate]);

  // New GPS points from the background tracker
  useEffect(() => subscribe((fresh) => send({ type: 'points', pts: flatten(fresh) })), [send]);

  // Refresh when coming back to the app; stop the live dot when leaving
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') { sync().then(() => startWatch(false)).catch(showError); }
      else stopWatch();
    });
    return () => { sub.remove(); stopWatch(); };
  }, [sync, startWatch, stopWatch]);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <WebView
        ref={web}
        style={styles.root}
        source={{ html: MAP_HTML, baseUrl: 'https://trailfog.app/' }}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        injectedJavaScriptBeforeContentLoaded={BEFORE_LOAD}
        onMessage={onMessage}
        overScrollMode="never"
        setBuiltInZoomControls={false}
        onRenderProcessGone={() => { ready.current = false; if (web.current) web.current.reload(); }}
        onContentProcessDidTerminate={() => { ready.current = false; if (web.current) web.current.reload(); }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1F27' },
});
