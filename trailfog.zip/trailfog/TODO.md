# TrailFog to-do

## Bugs
- [~] Double-tap on the map makes it jump (Android tester). Fixed in 1.5.1, waiting for tester to confirm.
- [ ] Trail gaps with weak GPS: fixed in 1.5.0, needs a real test ride (send the "Last ride GPS" line from Settings).

## Builds and stores
- [ ] Upload 1.6.0 zip (9 languages + Android battery fix), build Android + iPhone (Codespace: git pull first).
- [ ] App Store: add the 8 new languages to the listing (text + screenshots), submit 1.6.0.
- [ ] App Store review of 1.5.0 (submitted 28 Oct 2026).
- [ ] Expire TestFlight builds 1 and 2 once 1.5.0 is green.
- [ ] Delete Expo tokens that appeared in screenshots.
- [ ] Google Play: verify address with a Revolut statement (name and address exactly as in Play Console, under 90 days old).
- [ ] Google Play: closed test with 12+ testers for 14 days in a row, then apply for production.

## Community
- [ ] Discord: TrailFog category, channels, Tester role, pinned download + news posts, forum tags.
- [ ] Instagram: TestFlight link in bio, beta posters (EN/ES), stories with link sticker, promo video Reel.

## Server
- [ ] Check Supabase database size (free plan 500 MB). Past ~200 MB: move photos to Storage, speed up leaderboards.

## Features
- [ ] Group chat (with report/block on messages, update age rating).
- [ ] Offline area downloads again (MapTiler paid plan or another provider that allows it).
- [ ] Ads, later (trader status, App Privacy update, MapTiler paid plan first).

## Done
- [x] App in 9 languages (EN ES FR DE IT PT NL PL LV), follows the phone, picker in Settings
- [x] EU trader verification approved
- [x] Sign in with Apple / Google, delete account
- [x] Report and block
- [x] MapTiler maps
- [x] App Store listing, screenshots, privacy page, submitted for review
- [x] TestFlight beta approved, public link live
