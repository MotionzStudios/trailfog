// Takes the app screens from the demo map (needs internet for map tiles).
const { chromium } = require('playwright');
const path = require('path');
const MAP = 'file://' + path.resolve(__dirname, '../web/map.html');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 430, height: 932 }, deviceScaleFactor: 3 });
  await p.addInitScript(() => { window.TF_OS = 'ios'; });
  await p.goto(MAP);
  await p.addStyleTag({ content: '#toast{display:none!important} :root{--top-native:54px!important;--bottom-native:30px!important}' });
  await p.waitForTimeout(9000); // let the map tiles load
  await p.screenshot({ path: path.join(__dirname, 'map.png') });
  const click = (sel) => p.evaluate((s) => document.querySelector(s).click(), sel);
  const open = async (t) => { await click('[data-tab="' + t + '"]'); await p.evaluate(() => { document.getElementById('panel').hidden = false; }); await p.waitForTimeout(800); };
  await open('badges'); await p.screenshot({ path: path.join(__dirname, 'badges.png') });
  await open('group'); await p.screenshot({ path: path.join(__dirname, 'group.png') });
  await open('ranks'); await click('[data-act="worldJoin"]'); await p.waitForTimeout(900); await p.screenshot({ path: path.join(__dirname, 'ranks.png') });
  await open('settings'); await click('[data-act="addZone"]'); await p.waitForTimeout(500); await p.screenshot({ path: path.join(__dirname, 'settings.png') });
  await b.close();
})();
