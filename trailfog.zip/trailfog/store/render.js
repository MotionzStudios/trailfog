const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const OUT = path.join(__dirname, 'out'); fs.mkdirSync(OUT, { recursive: true });
const slides = [
  { img: 'map.png', k: 'TRAILFOG', h: 'THE MAP IS HIDDEN.<br><span>RIDE TO REVEAL IT.</span>', p: 'The fog clears along every trail you ride, even with your phone locked.' },
  { img: 'group.png', red: 1, k: 'RIDE CREWS', h: 'RIDE WITH<br><span>YOUR CREW</span>', p: 'Share a code and see everyone\'s trails, each in their own colour.' },
  { img: 'ranks.png', k: 'LEADERBOARDS', h: 'TOP THE<br><span>BOARD</span>', p: 'Weekly, monthly and all time. Your crew or riders worldwide.' },
  { img: 'badges.png', red: 1, k: 'BADGES', h: 'UNLOCK<br><span>EVERY BADGE</span>', p: 'Hit milestones and smash the monthly new-ground challenge.' },
  { img: 'settings.png', k: 'PRIVACY ZONES', h: 'HIDE<br><span>YOUR HOME</span>', p: 'Nothing inside a privacy zone is ever shared. Not with anyone.' },
];
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1290, height: 2796 } });
  for (let i = 0; i < slides.length; i++) {
    const s = slides[i];
    await p.goto('file://' + __dirname + '/slide.html');
    await p.evaluate((s) => { document.getElementById('k').textContent = s.k; document.getElementById('h').innerHTML = s.h; document.getElementById('p').textContent = s.p; document.getElementById('img').src = s.img; if (s.red) document.getElementById('s').classList.add('red'); }, s);
    await p.evaluate(async () => { await document.fonts.ready; const im = document.getElementById('img'); if (!im.complete) await new Promise(r => im.onload = r); });
    await p.screenshot({ path: path.join(OUT, `TrailFog-${i + 1}.png`) });
  }
  await b.close();
})();
