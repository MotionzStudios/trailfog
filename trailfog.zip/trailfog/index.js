import { registerRootComponent } from 'expo';

// The background GPS task must be defined before the app renders,
// so the OS can wake it up even when the screen is locked.
import './src/tracking';
import App from './App';

registerRootComponent(App);
