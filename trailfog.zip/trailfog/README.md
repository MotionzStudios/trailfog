# TrailFog

A phone app for trail riders (motorbikes, quads, MTB). The whole map starts covered in fog. Press **Start ride** and the fog clears along every trail you ride, even with the phone locked in your pocket or on the bars. Your cleared trails are saved on the phone and stay clear forever (until you reset).

Works on **Android and iPhone** (built with React Native + Expo).

## What's in it

| File | What it does |
|---|---|
| `App.js` | The screen: map, stats bar, Start/Stop ride button, layer + menu buttons |
| `src/FogOverlay.js` | Draws the fog over the map with your trails cut out of it (soft edges) |
| `src/tracking.js` | Background GPS task — keeps recording when the screen is off |
| `src/db.js` | Saves every GPS point to a small database on the phone |
| `src/geo.js` | Map maths: projecting GPS onto the screen, splitting trails at GPS gaps, area counter |

Features: fog clearing width (25/40/75 m), satellite / terrain toggle, "km² uncovered" counter, ride distance, follow-me mode, reset fog. GPS glitches (bad accuracy, impossible jumps) are filtered out so the fog doesn't clear in random straight lines.

## Getting it on your phone

You need a computer with **Node.js 20+** installed (https://nodejs.org).

```bash
cd trailfog
npm install
npx expo install --fix     # lines all packages up with the Expo version
```

> **Important:** background tracking does **not** work inside the "Expo Go" app. You need to build the real app. Pick one route:

### Route A — Android, easiest (cloud build, no Android Studio)

1. Get a Google Maps API key (free tier is fine): Google Cloud Console → enable **Maps SDK for Android** → create an API key. Paste it into `app.json` where it says `PASTE_YOUR_GOOGLE_MAPS_ANDROID_API_KEY_HERE`.
2. ```bash
   npm install -g eas-cli
   eas login                 # free Expo account
   eas build -p android --profile preview
   ```
3. When it finishes you get a link/QR code — open it on your phone and install the `.apk`.

### Route B — build locally

- Android: install Android Studio, plug in your phone with USB debugging, then `npx expo run:android`
- iPhone: needs a Mac with Xcode, then `npx expo run:ios --device`. (Installing on iPhones long-term or sharing with friends needs an Apple Developer account, $99/yr; then use `eas build -p ios`.)

## First ride checklist (on the phone)

1. Press **Start ride** and allow location.
2. When asked, choose **"Allow all the time"** (Android) / **"Always"** (iPhone). Without this, tracking stops when the screen locks.
3. **Android:** Settings → Apps → TrailFog → Battery → **Unrestricted**. Samsung, Xiaomi, Huawei etc. kill background apps aggressively otherwise.
4. You'll see a "TrailFog is mapping your ride" notification (Android) or the blue location pill (iPhone) — that means it's recording.

## Tweaking

- Fog look: `FOG_COLOR` / `FOG_OPACITY` in `src/FogOverlay.js` (set opacity to `1` for total fog).
- GPS filters: `MAX_ACCURACY_M`, `MIN_STEP_M`, `MAX_SPEED_MS` in `src/tracking.js`.
- When a trail gets split into separate pieces: `MAX_GAP_M` / `MAX_GAP_MS` in `src/geo.js`.
- App name / IDs: `app.json` (change `com.trailfog.app` to your own before publishing to the stores).

## Battery

High-accuracy GPS costs roughly the same as any ride-tracking app (Strava, Calimoto…): expect ~5–10% per hour. A handlebar USB charger is recommended for long days.

## Ideas for next versions

- Offline maps for areas with no signal (the fog and tracking already work offline; the map tiles don't).
- Export rides as GPX, import old GPX files to clear fog from past rides.
- Shared fog with your riding group.
- Achievements: "first 10 km² uncovered", new trails this week, etc.
