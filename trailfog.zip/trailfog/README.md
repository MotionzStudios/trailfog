# TrailFog

A phone app for trail riders (motorbikes, quads, MTB). The whole map starts covered in fog. Press **Start ride** and the fog clears along every trail you ride, even with the phone locked. Cleared trails are saved on the phone.

## How it's built

| File | What it does |
|---|---|
| `App.js` | Connects the phone's GPS and storage to the map screen |
| `web/map.html` | The map screen: trail map / satellite tiles, fog, stats, buttons |
| `src/mapHtml.js` | Generated copy of `map.html` (run `node scripts/build-map.js` after editing the map) |
| `src/tracking.js` | Background GPS task: keeps recording when the screen is off |
| `src/db.js` | Saves every GPS point on the phone |
| `src/geo.js` | Distance maths |
| `src/Boot.js` | Shows any error on screen instead of closing |

Maps: **OpenTopoMap** (trails, paths, contour lines) and **Esri satellite**. Both are free and need no API key. Fog and tracking work with no signal; map pictures need internet.

You can open `web/map.html` in a normal browser to try the map with a demo ride.

## Building

Built on GitHub with `.github/workflows/build.yml`: upload `trailfog.zip` to the repo and it builds an APK under **Releases**.

## On the phone

1. Press **Start ride**, allow location, and choose **Allow all the time**.
2. Settings → Apps → TrailFog → Battery → **Unrestricted**.

## Note on the free maps

OpenTopoMap and Esri allow light personal use. If you ever publish TrailFog for lots of users, switch to a paid or self-hosted tile service (change the `LAYERS` URLs in `web/map.html`).
