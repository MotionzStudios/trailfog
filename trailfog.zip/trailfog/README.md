# TrailFog

A phone app for trail riders (motorbikes, quads, MTB). The whole map starts covered in fog, and it clears along every trail you ride, even with the phone locked.

## Features

- **Fog map** on real trail maps (OpenTopoMap) or satellite (Esri), with live GPS and background tracking.
- **Photo pins:** take a photo and it's pinned where you stand.
- **Ride history:** every ride with distance, riding time and top speed; tap one to see it on the map or delete it.
- **GPX import:** add old rides from Strava, Wikiloc, Garmin, Komoot and others.
- **Offline maps:** save the map for an area so it shows with no signal.
- **Badges:** 16 milestones plus a monthly "new ground" challenge.
- **Groups:** ride with friends using an invite code. You see each other's cleared trails in your own colours, and their photo pins.
- **Leaderboards:** world (riders who opt in; only names and totals are shown) and your group, by new ground or distance, for this week, this month or all time.
- **Privacy zones:** nothing within a zone (e.g. around home) is ever uploaded.

## Files

| File | What it does |
|---|---|
| `App.js` | Connects GPS, storage, camera, groups and offline maps to the map screen |
| `web/map.html` | The map screen and menus (open it in a browser to try a demo) |
| `src/mapHtml.js` | Generated copy of `map.html` (`node scripts/build-map.js`) |
| `src/tracking.js` | Background GPS task |
| `src/db.js` | On-phone database |
| `src/photos.js`, `src/PhotoViewer.js` | Photo pins |
| `src/gpx.js` | GPX import |
| `src/offline.js` | Offline map downloads |
| `src/group.js`, `src/config.js` | Groups, leaderboards (Supabase) |
| `src/upload.js` | Upload maths: privacy zones, distance, new ground |
| `server/supabase-setup.sql` | One-time setup for your free Supabase server |
| `src/Boot.js` | Shows errors on screen instead of closing |

## Building

Upload `trailfog.zip` to the GitHub repo; `.github/workflows/build.yml` builds `TrailFog.apk` under **Releases**.
For groups, add the repo secrets `SUPABASE_URL` and `SUPABASE_KEY` (without them, the build still works with groups switched off).

## Notes

- Supabase's free plan pauses a project after about a week with no use. If groups stop working after a break, open supabase.com and press **Restore** on the project.
- OpenTopoMap and Esri allow light personal use only, which is why offline downloads are limited to small areas. If you ever publish TrailFog for lots of users, switch to a paid tile service.

## Keeping the leaderboard fair

The server works out every total itself from the uploaded points (the phone's own numbers are ignored).
Parts faster than 150 km/h or jumping more than 300 m don't count, scattered points earn no ground,
rides dated in the future or that look computer-made are flagged and never count, GPX imports don't count
on the world board, and the app ignores positions from "fake GPS" apps. Riders can report cheating from the
leaderboard; the admin queries at the bottom of `server/supabase-setup.sql` show reports and let you hide a rider.
